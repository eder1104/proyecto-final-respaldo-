import Apprentice from '../views/Apprentice.vue';
import Assignment from '../views/Assignment.vue';
import Binnacle from '../views/Binnacle.vue';
import Followup from '../views/Followup.vue';
import ForgottenPassword from '../views/ForgottenPassword.vue';
import Index from '../views/Index.vue';
import Fiche from '../views/Fiche.vue';
import Login from '../views/Login.vue';
import Modality from '../views/Modality.vue';
import Register from '../views/Register.vue';
import RessetPassword from '../views/ResetPassword.vue';
import Menu from '../layouts/Menu.vue'
import { createRouter, createWebHashHistory } from 'vue-router';

export const routes = [
    {
        path: '/menu', component: Menu, children: [
            { path: '/index', component: Index },
            { path: '/apprentice', component: Apprentice },
            { path: '/assignment', component: Assignment },
            { path: '/binnacle', component: Binnacle },
            { path: '/followup', component: Followup },
            { path: '/modality', component: Modality },
            { path: '/fiche', component: Fiche },
            { path: '/register', component: Register }
        ]
    },
    { path: '/', component: Login },
    { path: '/forgotten-password', component: ForgottenPassword },
    { path: '/reset-password', component: RessetPassword }


];

export const router = createRouter({
    // actualizar a futuro a createWebHistoy()
    history: createWebHashHistory(),
    routes
});