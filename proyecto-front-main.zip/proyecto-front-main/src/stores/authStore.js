import { defineStore } from "pinia";
import { ref } from "vue";

export const useAuthStore = defineStore("auth", () => {
    let tokenSave = ref("");
    let roleSave = ref("");

    function setToken(token) {
        if (token) {
            tokenSave.value = token;
        } else {
            console.log("No está llegando el token ", tokenSave);
        }
    }

    function getToken() {
        return tokenSave;
    }

    function setRole(role) {
        if (role) {
            roleSave.value = role;
        } else {
            console.log("No está llegando el rol ", roleSave);
        }
    }

    function getRole() {
        return roleSave;
    }

    return {
        setToken, getToken, tokenSave,
        setRole, getRole, roleSave
    };
}, {
    persist: true
});