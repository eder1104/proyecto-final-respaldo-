<!-- HeaderComponent.vue -->
<template>
    <div class="divTittle">
        <h1 class="text-h4">{{ title }}</h1>
        <div class="contBack">
            <q-btn @click="goBack()" class="btnBack">
                <q-icon name="arrow_back" />
            </q-btn>
        </div>
    </div>
</template>

<script setup>
import { ref } from 'vue';

import { useRouter } from 'vue-router';
const router = useRouter();

function goBack() {
    router.go(-1);
}

const props = defineProps({
    title: {
        type: String,
        required: true
    }
});
</script>

<style scoped>
.divTittle {
    display: flex;
    justify-content: center;
    border-bottom: 5px solid #308734;
    position: relative;
}

.divTittle h1 {
    color: #212121;
    font-size: 3em;
    font-weight: bold;
    margin: 0;
    padding: 20px 0 20px 0;
}

.contBack {
    position: absolute;
    left: 0;
    top: 0;
    padding: 20px;
}

.btnBack {
    color: #ffffff;
    background-color: #308734;
    border-radius: 50%;
    padding: 5px;
    margin: 0;
}
</style>