<script setup>
import { ref, computed ,onBeforeMount } from "vue";
import { QIcon } from "quasar";
import { useRouter } from "vue-router";
import { useAuthStore } from '../stores/authStore';
import iconSena from '../assets/img/icon.png';
import buttonsMenu from '../components/buttons/buttonsMenu.vue';

const leftDrawerOpen = ref(false);
const router = useRouter();
const authStore = useAuthStore();

function toggleLeftDrawer() {
  leftDrawerOpen.value = !leftDrawerOpen.value;
}
function exit() {
  const auth = JSON.parse(localStorage.getItem('auth')) || {};
  delete auth.roleSave;
  delete auth.tokenSave;
  localStorage.setItem('auth', JSON.stringify(auth));
  router.push('/');
}
// botones del menu
const allButtons = ref([
  { title: "Inicio", icon: "home_filled", to: "/index", roles: ["ETAPA PRODUCTIVA", "instructor"] },
  { title: "Aprendices", icon: "school", to: "/apprentice", roles: ["ETAPA PRODUCTIVA", "instructor"] },
  { title: "Asignación", icon: "task_alt", to: "/assignment", roles: ["ETAPA PRODUCTIVA", "instructor"] },
  { title: "Bitácora", icon: "list_alt", to: "/binnacle", roles: ["ETAPA PRODUCTIVA", "instructor"] },
  { title: "Seguimientos", icon: "supervisor_account", to: "/followup", roles: ["ETAPA PRODUCTIVA"] },
  { title: "Modalidad", icon: "info_outline", to: "/modality", roles: ["ETAPA PRODUCTIVA"] },
  { title: "Fiche", icon: "rule", to: "/fiche", roles: ["ETAPA PRODUCTIVA"] },
  { title: "Registro", icon: "assignment", to: "/register", roles: ["ETAPA PRODUCTIVA"] }
]);

// obtener solo los botones permitidos para el rol actual
const visibleButtons = computed(() => {
  return allButtons.value.filter(button => button.roles.includes(authStore.roleSave));
});

</script>

<template>
  <q-layout view="hHh Lpr lFf">

    <q-header elevated class="bg-green-9 text-white">
      <q-toolbar>
        <q-btn dense flat round icon="menu" @click="toggleLeftDrawer" />

        <q-toolbar-title class="titleHeader">
          <router-link to="/Index" class="title">
            REPFORA
          </router-link>
        </q-toolbar-title>

        <q-btn dense flat round icon="logout" @click="exit()" />
      </q-toolbar>
    </q-header>

    <q-drawer v-model="leftDrawerOpen" class="leftDrawer" side="left" overlay behavior="desktop" elevated>
      <q-item class="headerMenu">
        <q-item avatar class="no-padding">
          <q-avatar class="imgSena">
            <img :src="iconSena" />
          </q-avatar>
        </q-item>

        <q-item-section>
          <q-item-label>
            <div class="text-h5 text-bold">
              <p class="tittleMenu">Bienvenido</p>
              <p class="userMenu">{{ authStore.roleSave }}</p>
            </div>
          </q-item-label>
        </q-item-section>
      </q-item>

      <q-item class="bodyMenu">
        <q-item-section>
          <!-- botones  -->
          <buttonsMenu
            v-for="button in visibleButtons"
            :key="button.title"
            :title="button.title"
            :icon="button.icon"
            :to="button.to"
          />
        </q-item-section>
      </q-item>

    </q-drawer>

    <q-page-container>
      <router-view />
    </q-page-container>

    <q-footer class="bg-grey-4 text-black">
      <q-toolbar class="justify-center">
        <q-toolbar-title class="text-center">
          <div class="text-bold tittleFooter">REPFORA - Sena 2024 © Todos los derechos reservados</div>
        </q-toolbar-title>
      </q-toolbar>
    </q-footer>

  </q-layout>
</template>

<style scoped>
.bodyMenu {
  padding-top: 20px;
}

/* img */
.imgSena {
  width: 80px;
  height: 80px;
  margin-bottom: 20px;
}

/* Drawer */
.headerMenu {
  display: flex;
  flex-direction: column;
  align-items: center;
  padding: 20px 0;
  background: rgb(232, 232, 232);
  text-align: center;
}

/* Tittles and texts */
.tittleFooter {
  font-size: .75em;
}

.titleHeader {
  font-size: 1.5em;
  font-weight: 700;
  color: white;
  text-decoration: none;
  cursor: pointer;
  margin: 0;
}

.tittleMenu {
  font-size: 1em;
  font-weight: 700;
}

.title {
  color: white;
  text-decoration: none;
}

.userMenu {
  font-size: .8em;
  font-weight: 600;
}

.userEmail {
  font-size: .6em;
  font-weight: 500;
}

p {
  margin: 0;
  padding: 0;
}
</style>
