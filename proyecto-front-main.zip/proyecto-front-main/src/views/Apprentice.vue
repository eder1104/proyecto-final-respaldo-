<script setup>
import { ref, computed, onMounted } from "vue";
import { useQuasar } from "quasar";
import { getData, putData } from "../services/apiClient";
import { getRepforaData } from "../services/apiRepfora";
import StatusToggleTable from "../components/tables/StatusToggleTable.vue";
import ButtonAdd from "../components/buttons/ButtonAdd.vue";
import ModalCreateUpdate from "../components/modal/ModalCreateUpdate.vue";
import HeaderTable from "../layouts/HeaderTable.vue";
import filterSelect from "../components/selects/filterSelect.vue";
import { notifySuccessRequest, notifyErrorRequest, notifyWarningRequest } from "../utils/notify.js";


const fixed = ref(false);
const isEditing = ref(false);
const selectedFilter = ref(null);
const group = ref(null);

const $q = useQuasar();

let numDocument = ref("");
let tpDocument = ref("");
let firstName = ref("");
let lastName = ref("");
let email = ref("");
let phone = ref("");
let ficheName = ref("");
let ficheNumber = ref("");
let name = ref("");




onMounted(() => {
  getApprentices();

});

const columns = ref([
  {
    name: "no",
    required: true,
    align: "center",
    label: "N°",
    field: (row) => row,
    sortable: false,
  },
  {
    name: "fullName",
    required: true,
    align: "center",
    label: "Nombre Aprendiz",
    field: (row) => `${row.firstName} ${row.lastName}`,
    sortable: true,
  },
  {
    name: "tpDocument",
    required: true,
    align: "center",
    label: "Tipo de Documento",
    field: "tpDocument",
    sortable: true,
  },
  {
    name: "numDocument",
    required: true,
    align: "center",
    label: "N° Documento",
    field: "numDocument",
    sortable: true,
  },
  {
    name: "email",
    required: true,
    align: "center",
    label: "Email Personal",
    field: "email",
    sortable: true,
  },
  {
    name: "phone",
    align: "center",
    label: "Tel.",
    field: "phone",
    sortable: true,
  },
  {
    name: "ficheName",
    align: "center",
    label: "Ficha",
    field: (row) => row.fiche?.name || "",
    sortable: true,
  },
  {
    name: "ficheNumber",
    align: "center",
    label: "Cod. Ficha",
    field: (row) => row.fiche?.number || "",
    sortable: true,
  },
  {
    name: "name",
    required: true,
    align: "center",
    label: "Modalidad",
   field:  (row) => row.modality?.name || "",
    sortable: true,
  },
  {
    name: "status",
    align: "center",
    label: "Estado",
    field: "status",
    sortable: true,
  },
  {
    name: "opciones",
    required: true,
    align: "center",
    label: "Opciones",
  },
]);

const rows = ref([]);

async function getApprentices() {
  const res = await getData("apprentice/listallapprentice");
  rows.value = res;
  console.log(res);
  if (Array.isArray(res)) {
    return res.map((apprentice) => ({
      label: `${apprentice.firstName} ${apprentice.lastName} - ${apprentice.numDocument}`,
      value: apprentice._id,
      estado: apprentice.status,
    }));
  } else {
    console.error("La respuesta de la API no es un array");
    return [];
  }
}

// Cambiar getData por la función que obtiene las fichas de repfora y tambien cambiar logica de funcion

const ficheOptions = ref([]);

async function getFiches() {
  const res = await getRepforaData("fiches");
  console.log(res);
  if (Array.isArray(res)) {
    return res.map((fiche) => ({
      label: `${fiche.program.name} - ${fiche.number}`,
      value: fiche._id, // Cambia esto para usar el _id de MongoDB
      estado: fiche.status,
    }));
  } else {
    console.error("La respuesta de la API no es un array");
    return [];
  }
}

async function getStatus() {
  return [
    { label: "Activo", value: 1 },
    { label: "Inactivo", value: 2 },
    { label: "En etapa productiva", value: 3 },
    { label: "Por certificar", value: 4 },
    { label: "Certificado", value: 5 },
  ];
}

function openAddModal() {
  fixed.value = true;
  isEditing.value = false;
}

function openEditModal(row) {
  fixed.value = true;
  isEditing.value = true;
  // Implementa la lógica para abrir el modal de edición
  numDocument.value = row.numDocument;
  tpDocument.value = row.tpDocument;
  firstName.value = row.firstName;
  lastName.value = row.lastName;
  email.value = row.email;
  phone.value = row.phone;
  ficheName.value = row.fiche?.name ; 
  ficheNumber.value = row.fiche?.number ;

}

async function guardarAprendiz() {
  const data = {
    tpDocument: cc.value,
    numDocument: cc.value,
    firstName: nombre.value,
    lastName: nombre.value,
    phone: telefono.value,
    email: email.value,
  };
  const res = await putData("apprentice/saveapprentice", data);
  console.log(res);
  await getApprentices();
}

async function activate(id) {
  const res = await putData(`apprentice/enableapprentice/${id}`);
  console.log(res);
  await getApprentices();
}

async function deactivate(id) {
  const res = await putData(`apprentice/disableapprentice/${id}`);
  console.log(res);
  await getApprentices();
}

const tableButtons = [
  {
    icon: "edit",
    action: (row) => openEditModal(row),
    class: "icon-green"
  },
  {
    icon: "check",
    action: (row) => activate(row._id),
    condition: (row) => row.status == 2,
    class: "icon-activate"
  },
  {
    icon: "close",
    action: (row) => deactivate(row._id),
    condition: (row) => row.status != 2,
    class: "icon-deactivate"
  }
];

const filter = async () => {
  try {
    // Limpiar los datos anteriores
    rows.value = [];

    // Extraer el valor del filtro seleccionado
    const filterValue = selectedFilter.value?.value || selectedFilter.value;

    // Realizar la búsqueda basada en el filtro seleccionado
    let res;
    switch (group.value) {
      case 'option1':
        res = await getData(`/apprentice/listapprenticebyfiche/${filterValue}`);
        console.log(res);
        console.log(selectedFilter.value);
        break;
      case 'option2':
        res = await getData(`apprentice/listapprenticebystatus/${filterValue}`);
        console.log(res);
        console.log(selectedFilter.value);
        break;
      case 'option3':
      default:
        res = await getData(`apprentice/listapprenticebyid/${filterValue}`);
        console.log(res);
        console.log(selectedFilter.value);
        break;
    }

    // Verificar si se encontraron resultados
    if ((!Array.isArray(res) && typeof res !== 'object') || (Array.isArray(res) && res.length === 0)) {
      notifyWarningRequest('No se encontraron resultados');
    } else {
      // Actualizar los datos de la tabla
      notifySuccessRequest('Filtro aplicado correctamente');
      rows.value = Array.isArray(res) ? res : [res];
      console.log('Datos de la tabla:', res);
    }
  } catch (error) {
    console.error('Error al filtrar bitácoras:', error);
    notifyErrorRequest('Error al filtrar bitácoras');
  }
};

const radioButtons = [
  { label: 'Ficha', value: 'option1', },
  { label: 'Estado', value: 'option2' },
  { label: 'Aprendiz', value: 'option3' }
];

const getOptionsForSelectedRadio = computed(() => {
  switch (group.value) {
    case 'option1':
      console.log(group.value);
      return getFiches;
    case 'option2':
      console.log(group.value);
      return getStatus;
    case 'option3':
      console.log(group.value);
      return getApprentices;
    default:
      return null;
  }
});

const filterLabel = computed(() => {
  switch (group.value) {
    case 'option1':
      return 'Filtrar por Ficha';
    case 'option2':
      return 'Filtrar por Estado';
    case 'option3':
      return 'Filtrar por Aprendiz';
    default:
      return 'Seleccione un filtro';
  }
});

const valueFilter = computed(() => {
  switch (group.value) {
    case 'option1':
      return 'fiche._id';
    case 'option2':
      return 'status';
    case 'option3':
    default:
      return '_id';
  }
});

</script>

<template>
  <div class="q-gutter-md divMain">
    <div>
      <HeaderTable title="Aprendices" />
    </div>

    <div class="divFiltersAndButtons">
      <div class="filters">
        <div class="divFilter">
          <filterSelect :label="filterLabel" :value="valueFilter" :fetchOptions="getOptionsForSelectedRadio"
            v-model="selectedFilter" @filter="filter" />
        </div>
        <div class="q-pa-sm rounded-borders divRadioButtons">
          Filtrar por:
          <q-option-group inline :options="radioButtons" type="radio" v-model="group" />
        </div>
      </div>
      <ButtonAdd :openAddModal="openAddModal" />


      
    </div>

    <div>
      <StatusToggleTable :rows="rows" :columns="columns" :buttons="tableButtons" />
    </div>

    <ModalCreateUpdate :fixed="fixed" :isEditing="isEditing" entityName="Aprendices" iconName="school"
      @update:fixed="(val) => (fixed = val)">
      <template v-slot:modal-content>
        <q-select filled v-model="tpDocument" label="Tipo de Documento" :options="[
          'Cédula de Ciudadanía',
          'Tarjeta de Identidad',
          'Cédula de Extranjería',
          'Identificación de Extranjería'
        ]" class="input thin-input" label-color="green-9">
          <template v-slot:prepend>
            <q-icon color="green-10" name="folder_shared" />
          </template>
        </q-select>

        

        <q-input filled v-model="numDocument" label="Num. Documento" class="input thin-input" label-color="green-9">
          <template v-slot:prepend>
            <q-icon color="green-10" name="fingerprint" />
          </template>
        </q-input>

        <q-input filled v-model="firstName" label="Nombre" class="input thin-input" label-color="green-9">
          <template v-slot:prepend>
            <q-icon color="green-10" name="assignment_ind" />
          </template>
        </q-input>

        <q-input filled v-model="lastName" label="Apellido" class="input thin-input" label-color="green-9">
          <template v-slot:prepend>
            <q-icon color="green-10" name="person" />
          </template>
        </q-input>

        <q-input filled v-model="phone" label="Teléfono" class="input thin-input" label-color="green-9">
          <template v-slot:prepend>
            <q-icon color="green-10" name="call" />
          </template>
        </q-input>

        <q-input filled v-model="email" label="Email" class="input thin-input" label-color="green-9">
          <template v-slot:prepend>
            <q-icon color="green-10" name="mail" />
          </template>
        </q-input>

        <q-input filled v-model="ficheName" label="Nombre de Ficha" class="input thin-input" label-color="green-9">
          <template v-slot:prepend>
            <q-icon color="green-10" name="library_books" />
          </template>
        </q-input>

        <q-input filled v-model="ficheNumber" label="Num. Ficha" class="input thin-input" label-color="green-9">
          <template v-slot:prepend>
            <q-icon color="green-10" name="folder" />
          </template>
        </q-input>
      </template>
    </ModalCreateUpdate>
  </div>
</template>

<style scoped>
/* Inputs */

.input {
  margin: 7px 0;
  color: "green";
  border-color: "green"
}

/* divs */
.divMain {
  padding: 0 1.5%;
  margin-top: 20px;
}

/* Filters and buttons */
.divFiltersAndButtons {
  display: flex;
  justify-content: space-between;
  align-items: center;
}

.filters {
  display: flex;
  justify-content: center;
  align-items: center;
  gap: 30px;
}

.divFilter {
  width: auto;
}
</style>