<script setup>
import { ref, onMounted, computed } from "vue";
import { useQuasar } from "quasar";
import { getData, putData } from "../services/apiClient";
import { getRepforaData } from "../services/apiRepfora";
import tableBinnacleFollowup from "../components/tables/StatusSelectTable.vue";
import ButtonAdd from "../components/buttons/ButtonAdd.vue";
import ModalCreateUpdate from "../components/modal/ModalCreateUpdate.vue";
import HeaderTable from "../layouts/HeaderTable.vue"
import filterSelect from "../components/selects/filterSelect.vue";
import { notifySuccessRequest, notifyErrorRequest, notifyWarningRequest } from "../utils/notify.js";


const fixed = ref(false);
const isEditing = ref(false);
const $q = useQuasar();

const group = ref(null);
const selectedFilter = ref(null);

onMounted(() => {
    getBinnacles();
});

const columns = ref([
    {
        name: "no",
        required: true,
        align: "center",
        label: "N°",
        field: (row) => row,
        sortable: false,
    },
    {
        name: "etapaAsignada",
        required: true,
        align: "center",
        field: (row) => row.aprrentice,
        label: "Etapa productiva asignada",
        sortable: false
    },
    {
        name: "noBitacora",
        required: true,
        align: "center",
        label: "N° Bitacora",
        field: (row) => row.number,
    },
    {
        name: "noBitacora",
        required: true,
        align: "center",
        label: "N° Bitacora",
        field: (row) => row.number,
    },
    {
        name: "instructor",
        required: true,
        align: "center",
        label: "Instructor",
        field: (row) => row.instructor,
    },
    {
        name: "status",
        required: true,
        align: "center",
        label: "Estado",
        field: (row) => row.status
    },
    {
        name: "obs",
        required: true,
        align: "center",
        label: "Observaciones",
        field: "obs",
        sortable: false,
    }
]);

const rows = ref([
    {
        aprrentice: "Juan Daniel Uribe Pérez",
        instructor: "Instructor 1",
        number: 3,
    },
    {
        aprrentice: "Nicolas",
        instructor: "Instructor 2",
        number: 3,
    },
    {
        aprrentice: "Miguel",
        instructor: "Instructor 3",
        number: 3,
    }
]);

async function getBinnacles() {
    const res = await getData("binnacles/listallbinnacles");
    rows.value = res;
    console.log(res);
}

async function getInstructors() {
    const res = await getRepforaData("instructors");
    console.log(res);
    if (Array.isArray(res)) {
        return res.map((instructor) => ({
            label: `${instructor.name} - ${instructor.numdocument}`,
            value: instructor._id,
        }));
    } else {
        console.error("La respuesta de la API no es un array");
        return [];
    }
    return res;
}

async function getApprentices() {
    const res = await getData("apprentice/listallapprentice");
    rows.value = res;
    console.log(res);
    if (Array.isArray(res)) {
        return res.map((apprentice) => ({
            label: `${apprentice.firstName} ${apprentice.lastName} - ${apprentice.numDocument}`,
            value: apprentice._id,
            estado: apprentice.status,
        }));
    } else {
        console.error("La respuesta de la API no es un array");
        return [];
    }
}

function openAddModal() {
    fixed.value = true;
    isEditing.value = false;
}

function edit(row) {
    fixed.value = true;
    isEditing.value = true;
}

const tableButtons = [
    {
        icon: "search",
        action: (row) => activate(row._id),
        class: "icon-green"
    },
    {
        icon: "add",
        action: (row) => openAddModal(row),
        class: "icon-green"
    },

];

const filter = async () => {
    try {
        // Limpiar los datos anteriores
        rows.value = [];

        // Extraer el valor del filtro seleccionado
        const filterValue = selectedFilter.value?.value || selectedFilter.value;

        // Realizar la búsqueda basada en el filtro seleccionado
        let res;
        switch (group.value) {
            case 'option1':
                // res = await getData(`/apprentice/listapprenticebyfiche/${filterValue}`);
                console.log(res);
                console.log(selectedFilter.value);
                break;
            case 'option2':
            default:
                // res = await getData(`apprentice/listapprenticebyid/${filterValue}`);
                console.log(res);
                console.log(selectedFilter.value);
                break;
        }

        // Verificar si se encontraron resultados
        if ((!Array.isArray(res) && typeof res !== 'object') || (Array.isArray(res) && res.length === 0)) {
            notifyWarningRequest('No se encontraron resultados');
        } else {
            // Actualizar los datos de la tabla
            notifySuccessRequest('Filtro aplicado correctamente');
            rows.value = Array.isArray(res) ? res : [res];
            console.log('Datos de la tabla:', res);
        }
    } catch (error) {
        console.error('Error al filtrar bitácoras:', error);
        notifyErrorRequest('Error al filtrar bitácoras');
    }
};

const radioButtons = [
    { label: 'Instructor', value: 'option1', },
    { label: 'Aprendiz', value: 'option2' },
];

const getOptionsForSelectedRadio = computed(() => {
    switch (group.value) {
        case 'option1':
            console.log(group.value);
            return getInstructors;
        case 'option2':
            console.log(group.value);
            return getApprentices;
        default:
            return null;
    }
});

const filterLabel = computed(() => {
    switch (group.value) {
        case 'option1':
            return 'Filtrar por Instructor';
        case 'option2':
            return 'Filtrar por Aprendiz';
        default:
            return 'Seleccione un filtro';
    }
});

const valueFilter = computed(() => {
    switch (group.value) {
        case 'option1':
            return '_id';
        case 'option2':
        default:
            return '_id';
    }
});

</script>

<template>
    <div class="q-gutter-md divMain">
        <div>
            <HeaderTable title="Bitácoras" />
        </div>

        <div class="divFiltersAndButtons">
            <div class="filters">

                <div class="divFilter">
                    <filterSelect :label="filterLabel" :value="valueFilter" :fetchOptions="getOptionsForSelectedRadio"
                        v-model="selectedFilter" @filter="filter" />
                </div>

                <div class="q-pa-sm rounded-borders divRadioButtons">
                    Filtrar por:
                    <q-option-group inline :options="radioButtons" type="radio" v-model="group" />
                </div>

            </div>
            <ButtonAdd :openAddModal="openAddModal" />
        </div>

        <div>
            <tableBinnacleFollowup :rows="rows" :columns="columns" :openEditModal="edit" :buttons="tableButtons" />
        </div>
        <ModalCreateUpdate :fixed="fixed" :isEditing="isEditing" entityName="Observacion" iconName="task_alt"
            @update:fixed="val => fixed = val">

            <template v-slot:modal-content>
                <div class="q-gutter-md">
                    <div class="input">
                        <q-input filled label="Observaciones" type="textarea"
                            placeholder="agrege comentario a la bitacora" />
                    </div>
                </div>
            </template>

        </ModalCreateUpdate>
    </div>
</template>

<style scoped>
/* Inputs */

.input {
    margin-bottom: 10px;
}


/* divs */
.divMain {
    padding: 0 1.5%;
    margin-top: 20px;
}

/* Filters and buttons */
.divFiltersAndButtons {
    display: flex;
    justify-content: space-between;
    align-items: center;
}

.filters {
    display: flex;
    justify-content: center;
    align-items: center;
    gap: 30px;
}

.divFilter {
    width: auto;
}
</style>
