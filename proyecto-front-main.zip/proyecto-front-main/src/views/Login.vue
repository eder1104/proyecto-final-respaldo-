<script setup>
import { ref } from "vue";
import { postRepforaData } from "../services/apiRepfora.js";
import { postData } from "../services/apiClient.js";
import { notifySuccessRequest, notifyErrorRequest } from "../utils/notify.js";
import { validarCampos } from "../utils/validateFields.js";
import { useRouter } from 'vue-router';
import { useAuthStore } from '../stores/authStore';

const authStore = useAuthStore();
const $router = useRouter();
const email = ref("");
const password = ref("");
const numDocument = ref("");
const role = ref("");
let passwordVisible = ref(false);

const rolesOptions = ref([
  { value: 'ETAPA PRODUCTIVA', label: 'Administrador' },
  { value: 'instructor', label: 'Instructor' },
  { value: 'consultor', label: 'Consultor' },
]);

const isRole = (roles) => role.value === roles;

async function loginAdmin(email, password, role) {
  if (!validarCampos(email, password)) {
    return;
  }

  try {
    const res = await postRepforaData("users/login", { email, password, role });
    console.log(res);
    authStore.setToken(res.token); // Almacenar el token en el authStore
    authStore.setRole(role); // Almacenar el rol en el authStore
    notifySuccessRequest("Inicio de sesión exitoso");
    $router.push("/index");
  } catch (error) {
    notifyErrorRequest("Password/Email incorrecto");
    console.error(error);
  }
}

async function loginInstructor(email, password, role) {
  if (!validarCampos(email, password)) {
    return;
  }
  try {
    const res = await postRepforaData("instructors/login", { email, password, role });
    console.log(res);
    authStore.setToken(res.token); // Almacenar el token en el authStore
    authStore.setRole(role); // Almacenar el rol en el authStore
    notifySuccessRequest("Inicio de sesión exitoso");
    $router.push("/index");
  } catch (error) {
    notifyErrorRequest("Password/Email incorrecto");
    console.error(error);
  }
}

async function loginConsultor(email, numDocument, role) {
  if (!validarCampos(email, numDocument)) {
    return;
  }
  try {
    const res = await postData("apprentice/loginapprentice", { email, numDocument, role });
    console.log(res);
    authStore.setToken(res.token); // Almacenar el token en el authStore
    authStore.setRole(role); // Almacenar el rol en el authStore
    notifySuccessRequest("Inicio de sesión exitoso");
    $router.push("/index");
  } catch (error) {
    notifyErrorRequest("Document/Email incorrecto");
    console.error(error);
  }
}

async function handleLogin() {
  if (isRole('ETAPA PRODUCTIVA')) {
    await loginAdmin(email.value, password.value, role.value);
  } else if (isRole('instructor')) {
    await loginInstructor(email.value, password.value, role.value);
  } else if (isRole('consultor')) {
    await loginConsultor(email.value, numDocument.value, role.value);
  }
}
</script>

<template>
  <div>
    <q-layout view="lHh Lpr lFf">
      <q-page-container>
        <q-page class="flex flex-center bg-grey-2 q-pa-xs">
          <q-card class="q-pa-md shadow-3 my_card" bordered>

            <q-card-section class="headerRepfora text-white text-center">
              <img src="../assets/img/logo-blanco.png" alt="Logo Sena" class="header-logo" />
              REPFORA ETAPAS PRACTICAS
            </q-card-section>

            <q-card-section class="headerLogin text-center">
              <q-icon name="account_circle" size="118px" color="green-8" class="iconSena" />
              <div class="text-green-9 text-h5 text-weight-bold titleLogin">
                Inicia Sesión
              </div>
            </q-card-section>

            <!-- Inputs -->
            <q-card-section>
              <q-select filled label-color="green-10" color="green-8" class="input" dense v-model="role"
                :options="rolesOptions" emit-value option-label="label" option-value="value" map-options
                label="Seleccione su rol" use-input input-debounce="300" style="margin-bottom: 25px;">

                <template v-slot:prepend>
                  <q-icon color="green-8" name="list" />
                </template>
              </q-select>

              <q-input v-if="isRole('ETAPA PRODUCTIVA') || isRole('consultor') || isRole('instructor')" dense
                label-color="green-7" color="green-5" outlined class="input" v-model="email" label="Email Address"
                :rules="[val => !!val.trim() || 'El campo no puede estar vacío']">
                <template v-slot:prepend>
                  <q-icon name="email" color="green-8" />
                </template>
              </q-input>

              <q-input v-if="isRole('ETAPA PRODUCTIVA') || isRole('instructor')" dense label-color="green-7"
                color="green-5" outlined class="input" v-model="password" label="Password"
                :type="passwordVisible ? 'text' : 'password'"
                :rules="[val => !!val.trim() || 'El campo no puede estar vacío']">
                <template v-slot:prepend>
                  <q-icon name="lock" color="green-8" />
                </template>
                <template v-slot:append>
                  <q-icon :name="passwordVisible ? 'visibility' : 'visibility_off'" class="cursor-pointer"
                    @click="passwordVisible = !passwordVisible" />
                </template>
              </q-input>

              <q-input v-if="isRole('consultor')" dense label-color="green-7" color="green-5" outlined class="input"
                v-model="numDocument" label="Document" :rules="[val => !!val.trim() || 'El campo no puede estar vacío']">
                <template v-slot:prepend>
                  <q-icon name="assignment_ind" color="green-8" />
                </template>
              </q-input>
            </q-card-section>

            <!-- Botón  -->
            <q-card-section>
              <div class="button-container">
                <q-btn rounded label="Iniciar Sesión" no-caps class="small-btn btnLogin" @click="handleLogin" />
              </div>
            </q-card-section>
          </q-card>
        </q-page>
      </q-page-container>
    </q-layout>
  </div>
</template>

<style scoped>
.headerRepfora {
  background-color: #2E7D32;
  padding: 21px;
  color: white;
  font-weight: bold;
  font-size: 1.5em;
  display: flex;
  flex-direction: row;
  align-items: center;
  position: relative;
  justify-content: center;
}

.header-logo {
  width: 40px;
  height: auto;
  margin-bottom: 3px;
  position: absolute;
  left: 20px;
}

.headerLogin {
  display: flex;
  flex-direction: column;
  align-items: center;
  justify-content: center;
  margin-top: 20px;
}

.iconSena {
  margin-bottom: 0px;
}

.titleLogin {
  margin-top: 20px;
  color: #2E7D32;
}

.input {
  width: 100%;
  margin-top: 9px;
}

.btnLogin {
  background-color: #2E7D32;
  color: white;
  border-radius: 8px;
  font-size: 1rem;
  font-weight: bold;
}


.small-btn {
  padding: 10px 74px;
  font-size: 1rem;
}

.button-container {
  display: flex;
  justify-content: center;
  align-items: center;
}

.my_card {
  width: 46rem;
  border-radius: 12px;
  box-shadow: 0 20px 30px -5px rgba(180, 180, 180, 0.2),
    0 10px 15px -5px rgba(154, 154, 154, 0.2);
  background-color: white;
}
</style>
