<script setup>
import { onBeforeMount, ref, computed, watch } from 'vue';
import { useQuasar } from 'quasar';
import CardComponent from '../components/cards/cardsIndex.vue';
import { useAuthStore } from '../stores/authStore';

// Importa imágenes
import Imagen1 from "../assets/img/ima1.png";
import Imagen2 from "../assets/img/ima2.png";
import Imagen3 from "../assets/img/ima3.png";
import Imagen4 from "../assets/img/ima4.png";
import Imagen5 from "../assets/img/ima5.png";
import Imagen6 from "../assets/img/ima6.png";




// Obtén el store de autenticación
const authStore = useAuthStore();

// Lista de todas las cards
const allCards = ref([
    { 
        defaultTitle: 'Aprendices', 
        titlesByRole: {}, 
        imgSrc: Imagen1, 
        to: '/apprentice', 
        roles: ['ETAPA PRODUCTIVA'] 
    },
    { 
        defaultTitle: 'Asignación', 
        titlesByRole: { instructor: 'Mis asignaciones' }, 
        imgSrc: Imagen2, 
        to: '/assignment', 
        roles: ['ETAPA PRODUCTIVA', 'instructor'] 
    },
    { 
        defaultTitle: 'Bitácora', 
        titlesByRole: {instructor: 'Mis Bitácoras'}, 
        imgSrc: Imagen5, 
        to: '/binnacle', 
        roles: ['ETAPA PRODUCTIVA', 'instructor'] 
    },
    { 
        defaultTitle: 'Seguimientos', 
        titlesByRole: {}, 
        imgSrc: Imagen4, 
        to: '/followup', 
        roles: ['ETAPA PRODUCTIVA','instructor'] 
    },
    { 
        defaultTitle: 'Modalidad', 
        titlesByRole: {}, 
        imgSrc: Imagen3, 
        to: '/modality', 
        roles: ['ETAPA PRODUCTIVA'] 
    },
    { 
        defaultTitle: 'Fichas', 
        titlesByRole: { instructor: 'Mis fichas' }, 
        imgSrc: Imagen6, 
        to: '/fiche', 
        roles: ['ETAPA PRODUCTIVA', 'instructor'] 
    }
]);

// Computed para filtrar y personalizar las cards visibles según el rol del usuario
const visibleCards = computed(() => {
    return allCards.value
        .filter(card => card.roles.includes(authStore.roleSave))
        .map(card => ({
            ...card,
            title: card.titlesByRole[authStore.roleSave] || card.defaultTitle
        }));
});

onBeforeMount(() => {
    console.log("Rol en authStore:", authStore.roleSave);
});

watch(
    () => authStore.role,
    (newRole) => {
        console.log("Nuevo rol detectado:", newRole);
    }
);
</script>

<template>
    <div v-if="visibleCards.length > 0" class="q-pa-xl row items-center justify-center q-gutter-md contenedor">
        <div v-for="card in visibleCards" :key="card.defaultTitle">
            <CardComponent :title="card.title" :imgSrc="card.imgSrc" :to="card.to" />
        </div>
    </div>
</template>


<style scoped>
/* Contenedor */
.contenedor {
    padding-top: 25px;
}
</style>
