<script setup>
import { ref, onBeforeMount } from "vue";
import { useQuasar } from "quasar";
import { getData, putData } from "../services/apiClient";
import StatusToggleTable from "../components/tables/StatusToggleTable.vue";
import ButtonAdd from "../components/buttons/ButtonAdd.vue";
import ModalCreateUpdate from "../components/modal/ModalCreateUpdate.vue";
import HeaderTable from "../layouts/HeaderTable.vue"

const fixed = ref(false);
const isEditing = ref(false);
const $q = useQuasar();

onBeforeMount(() => {
  getModality();
});

const columns = ref([
{
    name: "no",
    required: true,
    align: "center",
    label: "N°",
    field: (row) => row,
    sortable: false,
  },
  {
    name: "fullName",
    required: true,
    align: "center",
    label: "Nombre Aprendiz",
    field: (row) => `${row.firstName} ${row.lastName}`,
    sortable: true,
  },
  {
    name: "ficheNumber",
    align: "center",
    label: "Cod. Ficha",
    field: (row) => row.fiche?.number || "",
    sortable: true,
  },
  {
    name: "name",
    required: true,
    align: "center",
    label: "Modalidad",
   field:  (row) => row.modality?.name || "",
    sortable: true,
  },
  {
    name: "instructorFollow.name",
    label: "Ins.Seguimiento",
    field: "instructorFollow.name",
    align: 'center'
  },
  {
    name: "instructorTechnical.name",
    label: "Ins.Técnico",
    field: "instructorTechnical.name",
    align: 'center'
  },
  {
    name: "instructorProject.name",
    label: "Ins. Proyecto",
    field: "instructorProject.name",
    align: 'center'
  },

  { name: "status", label: "Estado", field: "status", align: 'center' },
  { name: "binnacle", label: "Bitácora", field: "binnacle", align: 'center' },
  { name: "followup", label: "Seguimiento", field: "followup", align: 'center' },
  {
    name: "opciones",
    required: true,
    align: "center",
    label: "Opciones",
    align: 'center'
  }
]);

const rows = ref([]);

async function getModality() {
  const res = await getData("assignment/listallassignment");
  rows.value = res;
  console.log(res);
}

function openAddModal() {
  fixed.value = true;
  isEditing.value = false;
}

function openEditModal(row) {
  fixed.value = true;
  isEditing.value = true;
}

function guardar() {
  const data = {
    tpDocument: cc.value,
    numDocument: cc.value,
    firstName: nombre.value,
    lastName: nombre.value,
    phone: telefono.value,
    email: email.value
  };
}

async function activate(id) {
  const res = await putData(`assignment/enableassignmentbyid/${id}`);
  console.log(res);
  await getAssignment();

}

async function deactivate(id) {
  const res = await putData(`assignment/disableassignmentbyid/${id}`);
  console.log(res);
  await getAssignment();
}

</script>

<template>
  <div class="q-gutter-md divMain">
    <div>
      <HeaderTable title="Asignaciones" />
    </div>
    <div>
      <ButtonAdd :openAddModal="openAddModal" />
    </div>
    <div>
      <StatusToggleTable :rows="rows" :columns="columns" :openEditModal="openEditModal" :activate="activate"
        :deactivate="deactivate" />
    </div>

    <ModalCreateUpdate :fixed="fixed" :isEditing="isEditing" :openEditModal="openEditModal" :guardar="guardar"
      entityName="Asignación" iconName="task_alt" @update:fixed="val => fixed = val">
      <template v-slot:modal-content>
        <q-input filled v-model="instructorFollow" label="Instructor Seguimiento" class="input thin-input"
          label-color="green-9">
          <template v-slot:prepend>
            <q-icon color="green-10" name="supervisor_account" />
          </template>
        </q-input>

        <q-input filled v-model="instructorTechnical" label="Instructor Técnico" class="input thin-input"
          label-color="green-9">
          <template v-slot:prepend>
            <q-icon color="green-10" name="engineering" />
          </template>
        </q-input>

        <q-input filled v-model="instructorProject" label="Instructor Proyecto" class="input thin-input"
          label-color="green-9">
          <template v-slot:prepend>
            <q-icon color="green-10" name="business_center" />
          </template>
        </q-input>

        <q-input filled v-model="certificationDoc" label="Certificación Doc" class="input thin-input"
          label-color="green-9">
          <template v-slot:prepend>
            <q-icon color="green-10" name="verified" />
          </template>
        </q-input>

        <q-input filled v-model="judymentPhoto" label="Foto" class="input thin-input" label-color="green-9">
          <template v-slot:prepend>
            <q-icon color="green-10" name="photo_camera" />
          </template>
        </q-input>
      </template>
    </ModalCreateUpdate>
  </div>
</template>

<style scoped>
/* Inputs */

.input {
  margin: 7px 0;
  color: "green";
  border-color: "green"
}

/* divs */
.divMain {
  padding: 0 1.5%;
  margin-top: 20px;
}
</style>
