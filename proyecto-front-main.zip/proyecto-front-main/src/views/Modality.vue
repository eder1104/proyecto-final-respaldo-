<script setup>
import { ref, onBeforeMount } from "vue";
import { useQuasar } from "quasar";
import tablaModality from "../components/tables/CleanTable.vue";
import { getData } from "../services/apiClient";
import ButtonAdd from "../components/buttons/ButtonAdd.vue";
import ModalCreateUpdate from "../components/modal/ModalCreateUpdate.vue";
import HeaderTable from "../layouts/HeaderTable.vue"

const fixed = ref(false);
const isEditing = ref(false);
const $q = useQuasar();

onBeforeMount(() => {
    getModality()
});

const columns = ref([
    {
        name: 'name',
        required: true,
        align: 'center',
        label: 'Nombre',
        field: 'name',
        sortable: true
    },
    {
        name: 'hourInstructorFollow',
        align: 'center',
        label: 'Horas Instructor de Seguimiento',
        field: 'hourInstructorFollow',
        sortable: true
    },
    {
        name: 'hourInstructorTechnical',
        align: 'center',
        label: 'Horas Instructor Técnico',
        field: 'hourInstructorTechnical',
        sortable: true
    },
    {
        name: 'hourInstructorProject',
        align: 'center',
        label: 'Horas Instructor de Proyecto',
        field: 'hourInstructorProject',
        sortable: true
    }
]);

const rows = ref([
]);
async function getModality() {
    const res = await getData("modality/listallmodality");
    rows.value = res;
    console.log(res);
}
function openAddModal() {
    fixed.value = true;
    isEditing.value = false;
}

function edit(row) {
    fixed.value = true;
    isEditing.value = true;
}
</script>

<template>
    <div class="q-gutter-md divMain">
        <div>
            <HeaderTable title="Modalidad" />
        </div>
        <div>
            <ButtonAdd :openAddModal="openAddModal" />
        </div>
        <div>
            <StatusToggleTable :rows="rows" :columns="columns" :openEditModal="edit" :activate="activate"
                :deactivate="deactivate" />
        </div>

        <ModalCreateUpdate :fixed="fixed" :isEditing="isEditing" entityName="Modalidad" iconName="info_outline"
            @update:fixed="val => fixed = val">
            <template v-slot:modal-content>
                <q-input filled 
                    v-model="name" 
                    label="Nombre" 
                    class="input thin-input"
                    label-color="green-9">
                    <template v-slot:prepend>
                        <q-icon color="green-10" name="label" />
                    </template>
                </q-input>
                <q-input filled 
                    v-model="hourInstructorFollow" 
                    label="Horas Instructor de Seguimiento" 
                    class="input thin-input"
                    label-color="green-9">
                    <template v-slot:prepend>
                        <q-icon color="green-10" name="access_time" />
                    </template>
                </q-input>
                <q-input filled 
                    v-model="hourInstructorTechnical" 
                    label="Horas Instructor Técnico" 
                    class="input thin-input"
                    label-color="green-9">
                    <template v-slot:prepend>
                        <q-icon color="green-10" name="access_time" />
                    </template>
                </q-input>
                <q-input filled 
                    v-model="hourInstructorProject" 
                    label="Horas Instructor de Proyecto" 
                    class="input thin-input"
                    label-color="green-9">
                    <template v-slot:prepend>
                        <q-icon color="green-10" name="access_time" />
                    </template>
                </q-input>
            </template>
        </ModalCreateUpdate>


        <div>
            <tablaModality :rows="rows" :columns="columns" />
        </div>
    </div>
</template>

<style scoped>
/* Inputs */

.input {
    margin-bottom: 10px;
}

/* divs */
.divMain {
    padding: 0 1.5%;
    margin-top: 20px;
}
</style>