<script setup>
import { ref, computed, onMounted, watch } from "vue";
import { useQuasar } from "quasar";
import { getRepforaData } from "../services/apiRepfora";
import StatusToggleTable from "../components/tables/StatusToggleTable.vue";
import HeaderTable from "../layouts/HeaderTable.vue";
import filterSelect from "../components/selects/filterSelect.vue";
import { useRouter } from 'vue-router';

const fixed = ref(false);
const isEditing = ref(false);
const group = ref(null);

const $q = useQuasar();
const router = useRouter();


let filterLabel = ref("Ficha");
let valueFilter = ref("_id");



onMounted(() => {
  getFiches();
});

const columns = ref([
  {
    name: "no",
    required: true,
    align: "center",
    label: "N°",
    field: (row) => row,
    sortable: false,
  },
  {
    name: "ficheName",
    required: true,
    align: "center",
    label: "Nombre Ficha",
    field: (row) => row.program?.name || "",
    sortable: true,
  },
  {
    name: "ficheCode",
    required: true,
    align: "center",
    label: "Cod. Ficha",
    field: (row) => row.number || "",
    sortable: true,
  },

  {
    name: "status",
    align: "center",
    label: "Estado",
    field: "status",
    sortable: true,
  },
  {
    name: "opciones",
    required: true,
    align: "center",
    label: "Ver Aprendices",
  },
]);

const rows = ref([]);

// Cambiar getData por la función que obtiene las fichas de repfora y tambien cambiar logica de funcion

async function getFiches() {
  const res = await getRepforaData("fiches");
  rows.value = res;
  console.log(res);
  if (Array.isArray(res)) {
    return res.map((fiche) => ({
      label: `${fiche.program.name} - ${fiche.number}`,
      value: fiche.number,
      estado: fiche.status,
    }));
  } else {
    console.error("La respuesta de la API no es un array");
    return [];
  }
}



//direccion de la vista de aprendices
const tableButtons = [
      {
        icon: "remove_red_eye",
        action: () => router.push('/apprentice'), 
        class: "icon-green",
      },
    ];
    

const filter = async () => {
  console.log('Filtrando:', group.value, selectedFilter.value);


  try {
    // Limpiar los datos anteriores
    rows.value = [];

    // Realizar la búsqueda basada en el filtro seleccionado
    let res = await getRepforaData("fiches");

    // Verificar si se encontraron resultados
    if (!res.data || res.data.length === 0) {
      $q.notify({
        type: 'warning',
        message: 'No se encontraron resultados con la búsqueda.'
      });
    } else {
      // Actualizar los datos de la tabla
      $q.notify({
        type: 'positive',
        message: 'Filtros aplicados correctamente.'
      });
      rows.value = res.data;
      console.log('Datos de la tabla:', res.data);
      // exportableData.value = [...res.data] //guardamos los datos de las tablas
    }
  } catch (error) {
    console.error('Error al filtrar bitácoras:', error);
    $q.notify({
      type: 'negative',
      message: 'Error al filtrar bitácoras'
    });
  }
};

</script>

<template>
  <div class="q-gutter-md divMain">
    <div>
      <HeaderTable title="Fichas" />
    </div>

    <div class="divFiltersAndButtons">
      <div class="filters">
        <div class="divFilter">
          <filterSelect :label="filterLabel" :value="valueFilter" :fetchOptions="getFiches"
             @filter="filter" />
        </div>
      </div>
    </div>

    <div>
      <StatusToggleTable
        :rows="rows"
        :columns="columns"
        :buttons="tableButtons"
      />
    </div>
    
  </div>
</template>

<style scoped>
/* Inputs */

.input {
  margin: 7px 0;
  color: "green";
  border-color: "green";
}

/* divs */
.divMain {
  padding: 0 1.5%;
  margin-top: 20px;
}

/* Filters and buttons */
.divFiltersAndButtons {
  display: flex;
  justify-content: space-between;
  align-items: center;
}

.filters {
  display: flex;
  justify-content: center;
  align-items: center;
  gap: 30px;
}

.divFilter {
  width: auto;
}
</style>