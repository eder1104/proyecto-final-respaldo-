<script setup>
import { ref, computed, onMounted, watch } from "vue";
import { useQuasar } from "quasar";
import { getData, putData } from "../services/apiClient";
import { getRepforaData } from "../services/apiRepfora";
import StatusToggleTable from "../components/tables/StatusToggleTable.vue";
import ButtonAdd from "../components/buttons/ButtonAdd.vue";
import ModalCreateUpdate from "../components/modal/ModalCreateUpdate.vue";
import HeaderTable from "../layouts/HeaderTable.vue";
import filterSelect from "../components/selects/filterSelect.vue";

const fixed = ref(false);
const isEditing = ref(false);
const selectedFilter = ref(null);
const group = ref(null);

const $q = useQuasar();

let cc = ref("");
let nombre = ref("");
let email = ref("");
let telefono = ref("");

onMounted(() => {
  // getApprentices();
  getModality();
});

const columns = ref([
  {
    name: "no",
    required: true,
    align: "center",
    label: "N°",
    field: (row) => row,
    sortable: false,
  },
  {
    name: "fullName",
    required: true,
    align: "center",
    label: "Nombre Aprendiz",
    field: (row) => `${row.apprentice?.firstName} ${row.apprentice?.lastName}`,
    sortable: true,
  },
  {
    name: "ficheName",
    align: "center",
    label: "Ficha",
    field: (row) => row.apprentice?.fiche?.name || "",
    sortable: true,
  },
  {
    name: "name",
    required: true,
    align: "center",
    label: "Modalidad",
   field:  (row) => row.modality?.name || "",
    sortable: true,
  },
  {
        name: 'startDate',
        required: true,
        align: 'center',
        label: 'Fecha de Inicio',
        field: 'startDate',
        sortable: true
    },
    {
        name: 'endDate',
        required: true,
        align: 'center',
        label: 'Fecha de Fin',
        field: 'endDate',
        sortable: true
    },
  {
    name: "status",
    align: "center",
    label: "Estado",
    field: "status",
    sortable: true,
  },
  {
    name: "opciones",
    required: true,
    align: "center",
    label: "Opciones",
  },
]);

const rows = ref([]);

async function getApprentices() {
  const res = await getData("apprentice/listallapprentice");
  rows.value = res;
  console.log(res);
  if (Array.isArray(res)) {
    return res.map((apprentice) => ({
      label: `${apprentice.firstName} ${apprentice.lastName} - ${apprentice.numDocument}`,
      value: apprentice.numDocument,
      estado: apprentice.status,
    }));
  } else {
    console.error("La respuesta de la API no es un array");
    return [];
  }
}

// Cambiar getData por la función que obtiene las fichas de repfora y tambien cambiar logica de funcion

async function getFiches() {
  const res = await getRepforaData("fiches");
  console.log(res);
  if (Array.isArray(res)) {
    return res.map((fiche) => ({
      label: `${fiche.program.name} - ${fiche.number}`,
      value: fiche.number,
      estado: fiche.status,
    }));
  } else {
    console.error("La respuesta de la API no es un array");
    return [];
  }
}
async function getModality() {
  const res = await getData("register/listallregister");
  console.log(res);
  if (Array.isArray(res)) {
    rows.value = res;
  } else {
    console.error("La respuesta de la API no es un array");
    return [];
  }
}


async function getStatus() {
  return [
    { label: "Activo", value: "1" },
    { label: "Inactivo", value: "0" },
  ];
}

function openAddModal() {
  fixed.value = true;
  isEditing.value = false;
}

function openEditModal(row) {
  fixed.value = true;
  isEditing.value = true;
  // Implementa la lógica para abrir el modal de edición
}

async function guardarFicha() {
  const data = {
    tpDocument: cc.value,
    numDocument: cc.value,
    firstName: nombre.value,
    lastName: nombre.value,
    phone: telefono.value,
    email: email.value,
  };
  const res = await putData("apprentice/saveapprentice", data);
  console.log(res);
  await getApprentices();
}

async function activate(id) {
  const res = await putData(`apprentice/enableapprentice/${id}`);
  console.log(res);
  await getApprentices();
}

async function deactivate(id) {
  const res = await putData(`apprentice/disableapprentice/${id}`);
  console.log(res);
  await getApprentices();
}

const tableButtons = [
  {
    icon: "edit",
    action: (row) => openEditModal(row),
    class: "icon-green"
  },
  {
    icon: "check",
    action: (row) => activate(row._id),
    condition: (row) => row.status == 0,
    class: "icon-activate"
  },
  {
    icon: "close",
    action: (row) => deactivate(row._id),
    condition: (row) => row.status != 0,
    class: "icon-deactivate"
  }
];

const filter = async () => {
  console.log('Filtrando:', group.value, selectedFilter.value);


  try {
    // Limpiar los datos anteriores
    rows.value = [];

    // Realizar la búsqueda basada en el filtro seleccionado
    let res;
    switch (group.value) {
      case 'option1':
        res = await getRepforaData("fiches");
        break;
      case 'option2':
        res = await getData(`apprentice/listapprenticebystatus/${selectedFilter.value}`);
        break;
      case 'option3':
      default:
        res = await getData(`apprentice/listapprenticebyid/${selectedFilter.value}`);
        break;
    }

    // Verificar si se encontraron resultados
    if (!res.data || res.data.length === 0) {
      $q.notify({
        type: 'warning',
        message: 'No se encontraron resultados con la búsqueda.'
      });
    } else {
      // Actualizar los datos de la tabla
      $q.notify({
        type: 'positive',
        message: 'Filtros aplicados correctamente.'
      });
      rows.value = res.data;
      console.log('Datos de la tabla:', res.data);
      // exportableData.value = [...res.data] //guardamos los datos de las tablas
    }
  } catch (error) {
    console.error('Error al filtrar bitácoras:', error);
    $q.notify({
      type: 'negative',
      message: 'Error al filtrar bitácoras'
    });
  }
};

const radioButtons = [
  { label: 'Ficha', value: 'option1', },
  { label: 'Aprendiz', value: 'option3' }
];

const getOptionsForSelectedRadio = computed(() => {
  switch (group.value) {
    case 'option1':
      console.log(group.value);
      return getFiches;
    case 'option2':
      console.log(group.value);
      return getStatus;
    case 'option3':
      console.log(group.value);
      return getApprentices;
    default:
      return null;
  }
});

const filterLabel = computed(() => {
  switch (group.value) {
    case 'option1':
      return 'Filtrar por Ficha';
    case 'option3':
      return 'Filtrar por Aprendiz';
    default:
      return 'Seleccione un filtro';
  }
});

const valueFilter = computed(() => {
  switch (group.value) {
    case 'option1':
      return 'fiche._id';
    case 'option2':
      return 'status';
    case 'option3':
    default:
      return 'numDocument';
  }
});

watch(group, async () => {
  await loadOptions();
});

// Cargar las opciones iniciales al iniciar la página y validar si la opción es una función para evitar errores de ejecución

const loadOptions = async () => {
  const fetchOptions = getOptionsForSelectedRadio.value;
  if (typeof fetchOptions === 'function') {
    selectedFilter.value = await fetchOptions();
  } else {
    selectedFilter.value = [];
  }
};

loadOptions();

</script>

<template>
  <div class="q-gutter-md divMain">
    <div>
      <HeaderTable title="Registro" />
    </div>

    <div class="divFiltersAndButtons">
      <div class="filters">

        <div class="divFilter">
          <filterSelect :label="filterLabel" :value="valueFilter" :fetchOptions="getOptionsForSelectedRadio"
            v-model="selectedFilter" @filter="filter" />
        </div>

        <div class="q-pa-sm rounded-borders divRadioButtons">
          Preferred genre:
          <q-option-group inline :options="radioButtons" type="radio" v-model="group" />
        </div>

      </div>
      <ButtonAdd :openAddModal="openAddModal" />
    </div>

    <div>
      <StatusToggleTable :rows="rows" :columns="columns" :buttons="tableButtons" />
    </div>

    <ModalCreateUpdate :fixed="fixed" :isEditing="isEditing" entityName="Registro" iconName="school"
      @update:fixed="(val) => (fixed = val)">
      <template v-slot:modal-content>

        <q-input filled v-model="fullName" label="Nombre Aprendiz" class="input thin-input" label-color="green-9">
          <template v-slot:prepend>
            <q-icon color="green-10" name="fingerprint" />
          </template>
        </q-input>

        <q-input filled v-model="name" label="Ficha" class="input thin-input" label-color="green-9">
          <template v-slot:prepend>
            <q-icon color="green-10" name="assignment_ind" />
          </template>
        </q-input>

        <q-input filled v-model="lastName" label="Modalidad" class="input thin-input" label-color="green-9">
          <template v-slot:prepend>
            <q-icon color="green-10" name="person" />
          </template>
        </q-input>

        <q-input filled v-model="phone" label="Fecha de Inicio" class="input thin-input" label-color="green-9">
          <template v-slot:prepend>
            <q-icon color="green-10" name="call" />
          </template>
        </q-input>

        <q-input filled v-model="email" label="Fecha de Fin" class="input thin-input" label-color="green-9">
          <template v-slot:prepend>
            <q-icon color="green-10" name="mail" />
          </template>
        </q-input>
      </template>
    </ModalCreateUpdate>
  </div>
</template>

<style scoped>
/* Inputs */

.input {
  margin: 7px 0;
  color: "green";
  border-color: "green"
}

/* divs */
.divMain {
  padding: 0 1.5%;
  margin-top: 20px;
}

/* Filters and buttons */
.divFiltersAndButtons {
  display: flex;
  justify-content: space-between;
  align-items: center;
}

.filters {
  display: flex;
  justify-content: center;
  align-items: center;
  gap: 30px;
}

.divFilter {
  width: auto;
}
</style>