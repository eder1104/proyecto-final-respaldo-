import axios from 'axios';

// Obtener el valor de 'auth' del localStorage y parsearlo
const authData = JSON.parse(localStorage.getItem('auth'));
const token = authData ? authData.tokenSave : null;
const role = authData ? authData.roleSave : null;

const apiClient = axios.create({
    baseURL: 'http://localhost:5001/api/',
    headers: {
        "token": token,
        "role": role
    }
});

const apiRepfora = axios.create({
    baseURL: 'http://89.116.49.65:4500/api/',
    headers: {
        "token": token,
        "role": role
    }
    // Puedes agregar headers u otras configuraciones aquí si es necesario
});

export { apiClient, apiRepfora };