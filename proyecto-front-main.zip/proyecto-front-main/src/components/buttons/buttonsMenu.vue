<template>
    <q-item clickable v-ripple active-class="linkColor" :to="to" class="item">
      <q-item-section avatar>
        <q-icon :name="icon" /> <!-- Icono del boton -->
      </q-item-section>
      <q-item-section>
        <q-item-label class="drawer-item">{{ title }}</q-item-label>
      </q-item-section>
    </q-item>
</template>

<script setup>

const props = defineProps({
    title: {
        type: String,
        required: true
    },
    icon: {
        type: String,
        required: true
    },
    to: {
        type: String,
        required: true
    }
});
</script>

<style scoped>
.drawer-item {
  color: #ffffff;
  font-weight: 600;
  font-size: 20px;
  font-style: normal;
}

/* items */
.item {
  padding: 10px 20px;
  margin: 10px 0;
  border-radius: 10px;
  transition: all .3s;
  background-color: #2E7D32;
  color: white;
}
  
.item:hover {
  background-color: #38803a;
  transform: scale(1.05);
}

.linkColor {
  background-color: rgb(39, 158, 21);
}


</style>