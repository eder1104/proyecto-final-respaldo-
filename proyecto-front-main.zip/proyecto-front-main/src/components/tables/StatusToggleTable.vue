<script setup>
import { format } from 'date-fns';
import { computed } from 'vue';
const props = defineProps({
    rows: {
        type: Array,
        required: true
    },
    columns: {
        type: Array,
        required: true
    },
    buttons: {
        type: Array,
        required: true
    }
});
const filteredButtons = computed(() => {
    return props.rows.map(row => {
        return props.buttons.filter(button => !button.condition || button.condition(row));
    });
});
</script>

<template>
    <div>
        <q-table class="tabla " :rows="rows" :columns="columns" row-key="name" flat bordered>
            <!-- Slot para la cabecera -->
            <template v-slot:header-cell="props">
                <q-th :props="props" class="customHeader">
                    {{ props.col.label }}
                </q-th>
            </template>

            <!-- slot para la columna N° -->
            <template v-slot:body-cell-no="props">
                <q-td :props="props">
                    {{ props.pageIndex + 1 }}
                </q-td>
            </template>

            <!-- Slot para la columna 'opciones' -->
            <template v-slot:body-cell-opciones="props">
                <q-td :props="props">
                    <slot name="opciones" :row="props.row">
                        <div>
                            <q-btn v-for="(button, index) in filteredButtons[props.rowIndex]" :key="index"
                                @click="button.action(props.row)" class="buttonsTable">
                                <q-icon :name="button.icon" :class="button.class"></q-icon>
                            </q-btn>
                        </div>
                    </slot>
                </q-td>
            </template>

            <!-- Slot para la columna 'estado' -->
            <template v-slot:body-cell-status="props">
                <q-td :props="props">
                    <p style="color:green" v-if="props.row.status == 1">Activo</p>
                    <p style="color:red" v-else>Inactivo</p>
                </q-td>
            </template>

            <!-- Slot para la columna 'fecha de creación' -->
            <template v-slot:body-cell-createdAt="props">
                <q-td :props="props">
                    {{ format(new Date(props.row.createdAt), 'dd/MM/yyyy') }}
                </q-td>
            </template>

            <!-- Slot para la columna 'fecha de actualización' -->
            <template v-slot:body-cell-updatedAt="props">
                <q-td :props="props">
                    {{ format(new Date(props.row.updatedAt), 'dd/MM/yyyy') }}
                </q-td>
            </template>
        </q-table>
    </div>
</template>

<style scoped>
/* Iconos de los botones */
.icon-green {
    color: #1f7d22;
}

.icon-activate {
    color: #339536;
    font-weight: bold;
}

.icon-deactivate {
    color: #F44336;
    font-weight: bold;
}



.buttonsTable {
    height: 20px;
    width: 40px;
    border-radius: 50%;
    font-size: 14px;
    margin: 2px 5px;
}

/* table */
.tabla {
    width: 100%;
}


.customHeader {
    font-size: 14px;
    font-weight: bold;
    color: #333;
    text-align: center;
    padding: 4px;
    margin: 0;
}
</style>