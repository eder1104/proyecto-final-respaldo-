<template>
    <div class="col-xs-12 col-sm-6 col-md-3">
        <q-card class="my-card" flat bordered>
            <q-img class="img" :src="imgSrc" />
            <q-card-section class="sectionCard">
                <div class="text-h6 tittle">{{ title }}</div>
            </q-card-section>
            <q-card-actions class="background-actions">
                <q-btn flat color="white" class="buttons bg-primary" :to="to">
                    Ver
                </q-btn>
            </q-card-actions>
        </q-card>
    </div>
</template>

<script setup>

const props = defineProps({
    title: {
        type: String,
        required: true
    },
    imgSrc: {
        type: String,
        required: true
    },
    to: {
        type: String,
        required: true
    }
});
</script>

<style scoped>
/* Cards */
.my-card {
    display: flex;
    flex-direction: column;
    border: none;
    overflow: hidden;
    transition: transform 0.3s ease, box-shadow 0.3s ease;
    border-radius: 22px;
    box-shadow: 0 4px 8px rgba(0, 0, 0, 0.2);
    margin: 10px;
    width: 350px;
}

.background-actions {
    background-color: #f5f5f5;
}

.my-card:hover {
    transform: scale(1.02);
    box-shadow: 0 8px 16px rgba(0, 0, 0, 0.3);
}

/* Buttons */
.buttons {
    font-size: 15px;
    color: #ededed;
    width: 100%;
    border-radius: 15px;
    padding: 10px 0;
    font-weight: bold;
    transition: background-color 0.3s ease;
}

/* Tittle */
.tittle {
    font-size: 1.2rem;
    font-weight: bold;
    text-align: center;
    margin: 5px 0;
    background-color: transparent;
}

/* Section Card */
.sectionCard {
    background-color: #f5f5f5;
    text-align: center;
}

/* Img */
.img {
    width: 100%;
    height: 200px;
    object-fit: cover;
    border-radius: 15px 15px 0 0;
}
</style>