<script setup>
import { ref, watch, computed } from 'vue';

const props = defineProps({
    label: {
        type: String,
        required: true
    },
    fetchOptions: {
        type: Function,
        required: true
    },
    optionDisable: {
        type: Function,
        default: () => false
    },
    value: {
        type: String,
        required: true
    }
});

const emit = defineEmits(['update:modelValue', 'filter']);

const selectedValue = ref(null);
const options = ref([]);
const originalOptions = ref([]);

// Carga las opciones al montar el componente si fetchOptions es una función

async function loadOptions() {
    if (typeof props.fetchOptions === 'function') {
        originalOptions.value = await props.fetchOptions();
        options.value = originalOptions.value;
    } else {
        originalOptions.value = [];
        options.value = [];
    }
}

function filterOptions(val, update) {
    if (val === '') {
        update(() => {
            options.value = originalOptions.value;
        });
        return;
    }

    update(() => {
        const needle = val.toLowerCase();
        options.value = originalOptions.value.filter(
            option => option.label.toLowerCase().indexOf(needle) > -1
        );
    });
}

watch(selectedValue, (newValue) => {
    emit('update:modelValue', newValue);
});

// Observa cambios en fetchOptions y recarga las opciones
watch(() => props.fetchOptions, async () => {
    await loadOptions();
}, { immediate: true });

const useInput = computed(() => {
    return selectedValue.value === null || selectedValue.value === '';
});

</script>

<template>
    <div class="select-container">
        <q-select filled label-color="green-10" color="green-7" class="input" v-model="selectedValue" :options="options"
            emit-value option-label="label" :option-value="value" map-options :label="label" :use-input="useInput"
            input-debounce="300" @filter="filterOptions" use-chips>
            <template v-slot:prepend>
                <q-icon color="green-10" name="list" />
            </template>
        </q-select>
        <q-btn round dense icon="search" @click="$emit('filter')" class="search-button" />
    </div>
</template>

<style scoped>
.select-container {
    display: flex;
    align-items: center;
    gap: 12px;
    padding: 7px;
    background-color: #e3e3e3;
    border-radius: 8px;
    height: 65px;

}

.input {
    height: 56px;
    max-width: 250px;
    min-width: 250px;
    white-space: nowrap;
    overflow: hidden;
    text-overflow: ellipsis;
    background-color: white;
    border-radius: 9px;
}

.q-select .q-field__control {
    font-size: 0.95rem;
}

.search-button {
    margin-left: 8px;
    color: white;
    background-color: #3a7d3a;
    box-shadow: 0 3px 6px rgba(0, 0, 0, 0.16);
    transition: background-color 0.3s ease;
}

.search-button:hover {
    background-color: #2f632f;
}
</style> 