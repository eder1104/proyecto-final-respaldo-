import register from "../models/register.js";

export const registerHelper = {
    validateDates: (startDate, endDate, req) => {
        const start = new Date(startDate);
        const end = new Date(endDate);

        if (isNaN(start.getTime()) || isNaN(end.getTime())) {
            throw new Error('Invalid date format');
        }
        if (start > end) {
            throw new Error('Start date must be earlier than end date');
        }
        // req.validatedDates = { start, end }; // Puedes almacenar las fechas validadas en req si necesitas usarlas después
    }
};

// yair bobo gei