// helper para obtener las horas asignadas a un instructor dependiendo su modalidad
import Instructor from "../models/register.js";

export const getHours = async (id) => {
    let hours = 0;
    const instructor = await Instructor.findById(id);
    if (instructor) {
        if (instructor.modality === 'full-time') {
        hours = 40;
        } else if (instructor.modality === 'part-time') {
        hours = 20;
        }
    }
    return hours;
    };

