import Apprentice from "../models/apprentice.js";
import { processRole } from "../middlewares/validateRole.js";
import { generarJWTaprendiz } from "../middlewares/validarJWT.js";

const httpApprentice = {
    listallapprentice: async (req, res) => {
        try {
            const apprentices = await Apprentice.find().populate("modality");
            res.status(200).json(apprentices);
        } catch (error) {
            res.status(500).json({ message: error.message });
        }
    },
    listapprenticebyid: async (req, res) => {
        try {
            const apprentice = await Apprentice.findById(req.params.id).populate("numDocument");
            if (!apprentice) return res.status(404).json({ message: "Aprendiz no encontrado" });
            res.status(200).json(apprentice);
        } catch (error) {
            res.status(500).json({ message: error.message });
        }
    },
    listapprenticebyfiche: async (req, res) => {
        try {
            const id = req.params.id;
            const apprentices = await Apprentice.find({ 'fiche.id': id});
            res.status(200).json(apprentices);
        } catch (error) {
            res.status(500).json({ message: error.message });
        }
    },
    listapprenticebystatus: async (req, res) => {
        try {
            // const apprentices = await Apprentice.find({ status: req.params.status }).populate("numDocument");
            const apprentices = await Apprentice.find({ status: req.params.status });
            res.status(200).json(apprentices);
        } catch (error) {
            res.status(500).json({ message: error.message });
        }
    },
    loginapprentice: async (req, res) => {
        const { email, numDocument, role } = req.body;

    // loginusuario: async (req, res) => {
    //     const { email, numDocument } = req.body;
    //     try {
    //         const apprentice = await Apprentice.findOne({ email });
    //         if (!apprentice) {
    //             return res.status(401).json({ msg: "Aprendiz / Documento no son correctos" });
    //         }
    
    //         if (apprentice.estado === 0) {
    //             return res.status(401).json({ msg: "Aprendiz inactivo" });
    //         }
    
    //         if (apprentice.numDocument !== numDocument) {
    //             return res.status(401).json({ msg: "El documento es incorrecto" });
    //         }
    
    //         const tokenLog = await generarJWT(apprentice._id);
    
    //         res.json({
    //             apprentice,
    //             tokenLog,
    //             message: "Login correcto"
    //         });
    //     } catch (error) {
    //         console.error(error.message);
    //         return res.status(500).json({ message: "Error en el servidor" });
    //     }
    // },

        try {
            const roleType = processRole(role);
            const apprentice = await Apprentice.findOne({ email });
            if (!apprentice) {
                return res.status(401).json({ msg: "Aprendiz / Documento no son correctos" });
            }
            if (apprentice.estado === 0) {
                return res.status(401).json({ msg: "Aprendiz inactivo" });
            }
            if (apprentice.numDocument !== numDocument) {
                return res.status(401).json({ msg: "El documento es incorrecto" });
            } 
            const tokenLog = await generarJWTaprendiz(apprentice._id);
            res.json({
                apprentice,
                role: roleType,
                tokenLog,
                message: "Login correcto"
            });
        } catch (error) {
            return res.status(500).json({ message: error.message });
        }
    },
    addapprentice: async (req, res) => {
        try {
            const apprentice = new Apprentice(req.body);
            await apprentice.save();
            res.status(201).json({ message: "Aprendiz añadido correctamente" });
        } catch (error) {
            res.status(500).json({ message: error.message });
        }
    },
    updateapprenticebyid: async (req, res) => {
        try {
            const updatedApprentice = await Apprentice.findByIdAndUpdate(req.params.id, req.body, { new: true });
            if (!updatedApprentice) return res.status(404).json({ message: "Aprendiz no encontrado" });
            res.status(200).json({ message: "Aprendiz actualizado correctamente" });
        } catch (error) {
            res.status(500).json({ message: error.message });
        }
    },
    updatecertification: async (req, res) => {
        const id = req.params.id;
        try {
            const updatedApprentice = await Apprentice.findByIdAndUpdate(id, { status: 5 }, { new: true });
            if (!updatedApprentice) return res.status(404).json({ message: "Aprendiz no encontrado" });
            res.json({ message: "Estado del aprendiz actualizado a CERTIFICADO" });
        } catch (error) {
            res.status(400).json({ message: "No se puede actualizar el estado del aprendiz", error });
        }
    },
    enableapprentice: async (req, res) => {
        try {
            const updatedApprentice = await Apprentice.findByIdAndUpdate(req.params.id, { status: 1 }, { new: true });
            if (!updatedApprentice) return res.status(404).json({ message: "Aprendiz no encontrado" });
            res.status(200).json({ message: "Aprendiz activado correctamente" });
        } catch (error) {
            res.status(500).json({ message: error.message });
        }
    },
    disableapprentice: async (req, res) => {
        try {
            const updatedApprentice = await Apprentice.findByIdAndUpdate(req.params.id, { status: 2 }, { new: true });
            if (!updatedApprentice) return res.status(404).json({ message: "Aprendiz no encontrado" });
            res.status(200).json({ message: "Aprendiz desactivado correctamente" });
        } catch (error) {
            res.status(500).json({ message: error.message });
        }
    },
};

export { httpApprentice };