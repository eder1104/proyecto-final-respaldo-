import Binnacles from "../models/binnacleEp.js";
import Register from "../models/register.js";

const httpBinnacles = {
    listallbinnacles: async (req, res) => {
        try {
            const binnacles = await Binnacles.find().populate("assignment");
            res.json(binnacles);
        } catch (error) {
            res.status(500).json({ message: error.message });
        }
    },
    listbinnaclesbyid: async (req, res) => {
        try {
            const id = req.params.id;
            const data = await Binnacles.findById(id);
            if (!data) return res.status(404).json({ message: "Bitácora no encontrada" });
            res.json(data);
        } catch (error) {
            res.status(500).json({ message: error.message });
        }
    },
    listbinnaclesbyassignment: async (req, res) => {
        try {
            const id = req.params.idassignment;
            const data = await Binnacles.find({ assignment: id });
            res.json(data);
        } catch (error) {
            res.status(500).json({ message: error.message });
        }
    },
    listbinnaclesbyinstructor: async (req, res) => {
        try {
            const id = req.params.idinstructor; 
            const data = await Binnacles.find({ instructor: id });
            res.json(data);
        } catch (error) {
            res.status(500).json({ message: error.message });
        }
    },
    addbinnacles: async (req, res) => {
        const body = req.body;
        try {
            const data = new Binnacles(body);
            await data.save();

            // generar la suma de horas en automatico al añadir una bitacora:
            // const assignment = await Binnacles.findById(body.assignment);
            // if (assignment) {
            //     assignment.totalHours = (assignment.totalHours || 0) + body.hours;
            //     await assignment.save();
            // }
            


            res.json({ message: "Bitácora agregada" });
        } catch (error) {
            res.status(400).json({ message: "No se puede agregar esta bitácora, inténtelo más tarde" });
        }
    },
    updatebinnaclesbyid: async (req, res) => {
        const id = req.params.id;
        const body = req.body;
        try {
            const updatedBinnacle = await Binnacles.findByIdAndUpdate(id, body, { new: true });
            if (!updatedBinnacle) return res.status(404).json({ message: "Bitácora no encontrada" });
            res.json({ message: "Bitácora actualizada" });
        } catch (error) {
            res.status(400).json({ message: "No se puede actualizar esta bitácora" });
        }
    },


    
    // ------------------------------------------------------------------------------------------
    // Validar horas técnicas
    checktecnicalhours: async (req, res) => {
        const { id, hours } = req.body;
        try {
            const register = await Register.findById(id);
            if (!register) return res.status(404).json({ message: "Registro no encontrado" });
            
            register.assignment.instructorTechnical.the.hours += hours;
            await register.save();
            
            res.json({ message: "Horas técnicas validadas y actualizadas" });
        } catch (error) {
            res.status(400).json({ message: "No se pudo validar las horas técnicas", error });
        }
    },

    // Validar horas de proyecto
    checkprojecthours: async (req, res) => {
        const { id, hours } = req.body;
        try {
            const register = await Register.findById(id);
            if (!register) return res.status(404).json({ message: "Registro no encontrado" });
            
            register.assignment.instructorProject.the.hours += hours;
            await register.save();
            
            res.json({ message: "Horas de proyecto validadas y actualizadas" });
        } catch (error) {
            res.status(400).json({ message: "No se pudo validar las horas de proyecto", error });
        }
    },
    // -----------------------------------------------------------------------------------------



    updatestatus: async (req, res) => {
        const id = req.params.id;
        const status = req.params.status;
        try {
            const updatedBinnacle = await Binnacles.findByIdAndUpdate(id, { status: status }, { new: true });
            if (!updatedBinnacle) return res.status(404).json({ message: "Bitácora no encontrada" });
            res.json({ message: "Estado actualizado" });
        } catch (error) {
            res.status(400).json({ message: "No se puede actualizar este estado", error });
        }
    }
}

export { httpBinnacles };
