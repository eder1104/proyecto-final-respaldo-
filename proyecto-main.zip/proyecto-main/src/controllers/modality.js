import mongoose from "mongoose";
import Modality from "../models/modality.js";

const httpModality = {
    listallmodality: async (req, res) => {
        try {
            const data = await Modality.find();
            res.status(200).json(data);
        } catch (error) {
            res.status(500).json({ message: error.message });
        }
    },
    listmodalitybyid: async (req, res) => {
        try {
            const id = req.params.id;
            if (!mongoose.Types.ObjectId.isValid(id)) {
                return res.status(400).json({ message: "Invalid ID format" });
            }
            const data = await Modality.findById(id);
            if (!data) return res.status(404).json({ message: "Modality not found" });
            res.status(200).json(data);
        } catch (error) {
            res.status(500).json({ message: error.message });
        }
    },
    addmodality: async (req, res) => {
        try {
            const body = req.body;
            const data = new Modality(body);
            await data.save();
            res.status(201).json({ message: "Modality added successfully" });
        } catch (error) {
            res.status(400).json({ message: "Failed to add modality, please try again" });
        }
    },
    updatemodalitybyid: async (req, res) => {
        try {
            const id = req.params.id;
            const body = req.body;

            if (!mongoose.Types.ObjectId.isValid(id)) {
                return res.status(400).json({ message: "Invalid ID format" });
            }

            const data = await Modality.findByIdAndUpdate(id, body, { new: true });
            if (!data) return res.status(404).json({ message: "Modality not found" });
            res.status(200).json({ message: "Modality updated successfully" });
        } catch (error) {
            res.status(400).json({ message: "Failed to update modality" });
        }
    },
    enablemodality: async (req, res) => {
        try {
            const id = req.params.id;
            if (!mongoose.Types.ObjectId.isValid(id)) {
                return res.status(400).json({ message: "Invalid ID format" });
            }

            const data = await Modality.findByIdAndUpdate(id, { status: "active" }, { new: true });
            if (!data) return res.status(404).json({ message: "Modality not found" });
            res.status(200).json({ message: "Modality enabled successfully" });
        } catch (error) {
            res.status(500).json({ message: error.message });
        }
    },
    disablemodality: async (req, res) => {
        try {
            const id = req.params.id;
            if (!mongoose.Types.ObjectId.isValid(id)) {
                return res.status(400).json({ message: "Invalid ID format" });
            }

            const data = await Modality.findByIdAndUpdate(id, { status: "inactive" }, { new: true });
            if (!data) return res.status(404).json({ message: "Modality not found" });
            res.status(200).json({ message: "Modality disabled successfully" });
        } catch (error) {
            res.status(500).json({ message: error.message });
        }
    }
}

export { httpModality };
