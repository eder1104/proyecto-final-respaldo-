import mongoose from "mongoose";
import Register from "../models/register.js";
import Assignment from "../models/register.js";
import { registerHelper } from '../helpers/registerHelper.js';


const httpRegister = {
    listallregister: async (req, res) => {
        try {
            const registers = await Register.find().populate("apprentice modality");
            res.status(200).json(registers);
        } catch (error) {
            res.status(500).json({ message: error.message });
        }
    },



    // -------------------------------------------------------------------------------------------------------------
    // listallregisterwithassignment: async (req, res) => {
    //     try {
    //         const registers = await Register.find().populate("apprentice modality").populate({
    //             path: "assignment",
    //             populate: ["instructorFollow", "instructorTechnical", "instructorProject"]
    //         });
    //         res.status(200).json(registers);
    //     } catch (error) {
    //         res.status(500).json({ message: error.message });
    //     }
    // },
    listallregisterwithassignment: async (req, res) => {
        try {
            const registers = await Register.find()
                .populate("apprentice modality")
                .populate({
                    path: "assignment.instructorFollow.id",
                })
                .populate({
                    path: "assignment.instructorTechnical.id",
                })
                .populate({
                    path: "assignment.instructorProject.id",
                });
            res.status(200).json(registers);
        } catch (error) {
            res.status(500).json({ message: error.message });
        }
    },
    // -------------------------------------------------------------------------------------------------------------
    
    
    
    listregisterbyid: async (req, res) => {
        try {
            const { id } = req.params;
            if (!mongoose.Types.ObjectId.isValid(id)) {
                return res.status(400).json({ message: "Invalid ID format" });
            }
            const register = await Register.findById(id).populate("apprentice modality");
            if (!register) return res.status(404).json({ message: "Registro no encontrado" });
            res.status(200).json(register);
        } catch (error) {
            res.status(500).json({ message: error.message });
        }
    },
    listregisterbyapprentice: async (req, res) => {
        try {
            const registers = await Register.find({ apprentice: req.params.idapprentice }).populate("apprentice modality");
            res.status(200).json(registers);
        } catch (error) {
            res.status(500).json({ message: error.message });
        }
    },
    listregistersbyfiche: async (req, res) => {
        try {
            const registers = await Register.find({ modality: req.params.idfiche }).populate("apprentice modality");
            res.status(200).json(registers);
        } catch (error) {
            res.status(500).json({ message: error.message });
        }
    },
    listregisterbymodality: async (req, res) => {
        try {
            const registers = await Register.find({ modality: req.params.idmodality }).populate("apprentice modality");
            res.status(200).json(registers);
        } catch (error) {
            res.status(500).json({ message: error.message });
        }
    },



    // ------------------------------------------------------------------------------------------------------------------
    // Listar registros por ID del instructor de seguimiento
    // listregisterepbyfollowupinstructor: async (req, res) => {
    //     try {
    //         const { idinstructor } = req.params;
    //         const assignments = await Assignment.find({ instructorFollow: idinstructor }).populate("register");
    //         res.status(200).json(assignments);
    //     } catch (error) {
    //         res.status(500).json({ message: error.message });
    //     }
    // },

    // // Listar registros por ID del instructor técnico
    // listregisterepbytechnicalinstructor: async (req, res) => {
    //     try {
    //         const { idinstructor } = req.params;
    //         const assignments = await Assignment.find({ instructorTechnical: idinstructor }).populate("register");
    //         res.status(200).json(assignments);
    //     } catch (error) {
    //         res.status(500).json({ message: error.message });
    //     }
    // },

    // // Listar registros por ID del instructor de proyecto
    // listregisterepbyprojectinstructor: async (req, res) => {
    //     try {
    //         const { idinstructor } = req.params;
    //         const assignments = await Assignment.find({ instructorProject: idinstructor }).populate("register");
    //         res.status(200).json(assignments);
    //     } catch (error) {
    //         res.status(500).json({ message: error.message });
    //     }
    // },


    // Listar registros por ID del instructor de seguimiento
    listregisterepbyfollowupinstructor: async (req, res) => {
        try {
            const { idinstructor } = req.params;
            const registers = await Register.find({ "assignment.instructorFollow.id": idinstructor }).populate("apprentice modality");
            res.status(200).json(registers);
        } catch (error) {
            res.status(500).json({ message: error.message });
        }
    },

    // Listar registros por ID del instructor técnico
    listregisterepbytechnicalinstructor: async (req, res) => {
        try {
            const { idinstructor } = req.params;
            const registers = await Register.find({ "assignment.instructorTechnical.id": idinstructor }).populate("apprentice modality");
            res.status(200).json(registers);
        } catch (error) {
            res.status(500).json({ message: error.message });
        }
    },

    // Listar registros por ID del instructor de proyecto
    listregisterepbyprojectinstructor: async (req, res) => {
        try {
            const { idinstructor } = req.params;
            const registers = await Register.find({ "assignment.instructorProject.id": idinstructor }).populate("apprentice modality");
            res.status(200).json(registers);
        } catch (error) {
            res.status(500).json({ message: error.message });
        }
    },
    // ------------------------------------------------------------------------------------------------------------------



    listregisterbystartdate: async (req, res) => {
        try {
            const startDate = req.params.startdate;
            registerHelper.validateDates(startDate, startDate);  // Validamos que sea una fecha válida
            const registers = await Register.find({ startDate: { $eq: new Date(startDate) } }).populate("apprentice modality");
            res.status(200).json(registers);
        } catch (error) {
            res.status(400).json({ message: error.message }); 
        }
    },
    listregisterbyenddate: async (req, res) => {
        try {
            const endDate = req.params.enddate;
            registerHelper.validateDates(endDate, endDate);  // Validamos que sea una fecha válida
            const registers = await Register.find({ endDate: { $eq: new Date(endDate) } }).populate("apprentice modality");
            res.status(200).json(registers);
        } catch (error) {
            res.status(400).json({ message: error.message });
        }
    },
    addregister: async (req, res) => {
        try {
            const { startDate, endDate } = req.body;
            registerHelper.validateDates(startDate, endDate, req);  // Usamos el helper de validación de fechas
            const register = new Register(req.body);
            await register.save();
            res.status(201).json({ message: "Registro ingresado" });
        } catch (error) {
            res.status(500).json({ message: error.message });
        }
    },
    updateregisterbyid: async (req, res) => {
        try {
            const { id } = req.params;
            const { startDate, endDate } = req.body;
    
            if (!mongoose.Types.ObjectId.isValid(id)) {
                return res.status(400).json({ message: "Invalid ID format" });
            }
    
            registerHelper.validateDates(startDate, endDate, req);  // Usamos el helper de validación de fechas
    
            const register = await Register.findByIdAndUpdate(id, req.body, { new: true });
            if (!register) return res.status(404).json({ message: "Registro no encontrado" });
            res.status(200).json({ message: "Registro actualizado correctamente" });
        } catch (error) {
            // handleError(res, error);
            res.status(500).json({ message: error.message });
        }
    },

    // ----------------------------------------------------------------------------------------------------------------------
    // updateassignmentregister: async (req, res) => {
    //     try {
    //         const { id } = req.params;
    //         const register = await Register.findById();
    //         if (!register) {
    //             register = await Register.findByIdAndUpdate(id, { Assignment }, { new: true });
    //         }
    //     } catch (error) {
    //         res.status(500).json({ message: error.message });
    //     }},


    updateassignmentregister: async (req, res) => {
        try {
            const { id } = req.params;
            const { assignment } = req.body;

            if (!mongoose.Types.ObjectId.isValid(id)) {
                return res.status(400).json({ message: "Invalid ID format" });
            }

            const register = await Register.findById(id);
            if (!register) return res.status(404).json({ message: "Registro no encontrado" });

            // Inactivar instructores anteriores si se está cambiando por uno nuevo
            if (assignment.instructorFollow && register.assignment.instructorFollow.id !== assignment.instructorFollow.id) {
                register.assignment.instructorFollow.status = 0;
            }
            if (assignment.instructorProject && register.assignment.instructorProject.id !== assignment.instructorProject.id) {
                register.assignment.instructorProject.status = 0;
            }
            if (assignment.instructorTechnical && register.assignment.instructorTechnical.id !== assignment.instructorTechnical.id) {
                register.assignment.instructorTechnical.status = 0;
            }

            register.assignment = { ...register.assignment, ...assignment };
            await register.save();
            res.status(200).json({ message: "Asignación actualizada correctamente" });
        } catch (error) {
            res.status(500).json({ message: error.message });
        }
    },
    // ----------------------------------------------------------------------------------------------------------------------

    updatemodalityregister: async (req, res) => {
        try {
            const { id } = req.params;
            const { modality } = req.body;
    
            if (!mongoose.Types.ObjectId.isValid(id)) {
                return res.status(400).json({ message: "Invalid ID format" });
            }
    
            if (!mongoose.Types.ObjectId.isValid(modality)) {
                return res.status(400).json({ message: "Invalid ID format" });
            }

            const register = await Register.findByIdAndUpdate(id, { modality }, { new: true });
            if (!register) return res.status(404).json({ message: "Registro no encontrado" });
            res.status(200).json({ message: "Registro actualizado correctamente" });
        } catch (error) {
            res.status(500).json({ message: error.message });
        }
    },
    enableregister: async (req, res) => {
        try {
            const register = await Register.findByIdAndUpdate(req.params.id, { status: 1 }, { new: true });
            if (!register) return res.status(404).json({ message: "Registro no encontrado" });
            res.status(200).json({ message: "Registro activado correctamente" });
        } catch (error) {
            res.status(500).json({ message: error.message });
        }
    },
    disableregister: async (req, res) => {
        try {
            const register = await Register.findByIdAndUpdate(req.params.id, { status: 0 }, { new: true });
            if (!register) return res.status(404).json({ message: "Registro no encontrado" });
            res.status(200).json({ message: "Registro desactivado correctamente" });
        } catch (error) {
            res.status(500).json({ message: error.message });
        }
    }
}

export { httpRegister };




// import Assignment from "../models/assignment.js";

// const httpAssignment = {
//     listallassignment: async (req, res) => {
//         try {
//             const data = await Assignment.find().populate('instructorFollow').populate('instructorTechnical').populate('instructorProject');
//             res.json(data);
//         } catch (error) {
//             res.status(500).json({ message: error.message });
//         }
//     },
//     listassignmentbyid: async (req, res) => {
//         try {
//             const id = req.params.id;
//             const data = await Assignment.findById(id);
//             if (!data) return res.status(404).json({ message: "Asignación no encontrada" });
//             res.json(data);
//         } catch (error) {
//             res.status(500).json({ message: error.message });
//         }
//     },
//     listassignmentbyregister: async (req, res) => {
//         try {
//             const id = req.params.idregister;
//             const data = await Assignment.find({ register: id });
//             res.json(data);
//         } catch (error) {
//             res.status(500).json({ message: error.message });
//         }
//     },
//     listfollowupinstructor: async (req, res) => {
//         try {
//             const idInstructor = req.params.idinstructor;
//             const data = await Assignment.find({ instructorFollow: idInstructor });
//             res.json(data);
//         } catch (error) {
//             res.status(500).json({ message: error.message });
//         }
//     },
//     listtechnicalinstructor: async (req, res) => {
//         try {
//             const idInstructor = req.params.idinstructor;
//             const data = await Assignment.find({ instructorTechnical: idInstructor });
//             res.json(data);
//         } catch (error) {
//             res.status(500).json({ message: error.message });
//         }
//     },
//     listprojectinstructor: async (req, res) => {
//         try {
//             const idInstructor = req.params.idinstructor;
//             const data = await Assignment.find({ instructorProject: idInstructor });
//             res.json(data);
//         } catch (error) {
//             res.status(500).json({ message: error.message });
//         }
//     },
//     addassignment: async (req, res) => {
//         const body = req.body;
//         try {
//             const data = new Assignment(body);
//             await data.save();
//             res.json({ message: "Asignación agregada" });
//         } catch (error) {
//             res.status(400).json({ message: error.message });
//         }
//     },
//     updateassignmentbyid: async (req, res) => {
//         const id = req.params.id;
//         const body = req.body;
//         try {
//             const updatedAssignment = await Assignment.findByIdAndUpdate(id, body, { new: true });
//             if (!updatedAssignment) return res.status(404).json({ message: "Asignación no encontrada" });
//             res.json({ message: "Asignación actualizada" });
//         } catch (error) {
//             res.status(400).json({ message: error.message });
//         }
//     },
//     enableassignmentbyid: async (req, res) => {
//         const id = req.params.id;
//         try {
//             const updatedAssignment = await Assignment.findByIdAndUpdate(id, { status: 1 }, { new: true });
//             if (!updatedAssignment) return res.status(404).json({ message: "Asignación no encontrada" });
//             res.json({ message: "Asignación habilitada" });
//         } catch (error) {
//             res.status(400).json({ message: error.message });
//         }
//     },
//     disableassignmentbyid: async (req, res) => {
//         const id = req.params.id;
//         try {
//             const updatedAssignment = await Assignment.findByIdAndUpdate(id, { status: 0 }, { new: true });
//             if (!updatedAssignment) return res.status(404).json({ message: "Asignación no encontrada" });
//             res.json({ message: "Asignación deshabilitada" });
//         } catch (error) {
//             res.status(400).json({ message: error.message });
//         }
//     }
// };

// export { httpAssignment };
