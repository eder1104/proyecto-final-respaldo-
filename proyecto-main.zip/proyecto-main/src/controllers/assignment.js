import Register from '../models/register.js'

const httpAssignment = {
    listallassignment: async (req, res) => {
        try {
            const data = await Register.find({}).populate('assignment')
            res.json(data);
        } catch (error) {
            res.status(500).json({ message: error.message });
        }
    },
    listassignmentbyid: async (req, res) => {
        try {
            const id = req.params.id;
            const data = await Assignment.findById(id);
            if (!data) return res.status(404).json({ message: "Asignación no encontrada" });
            res.json(data);
        } catch (error) {
            res.status(500).json({ message: error.message });
        }
    },
    listassignmentbyregister: async (req, res) => {
        try {
            const id = req.params.idregister;
            const data = await Assignment.find({ register: id });
            res.json(data);
        } catch (error) {
            res.status(500).json({ message: error.message });
        }
    },
    listfollowupinstructor: async (req, res) => {
        try {
            const idInstructor = req.params.idinstructor;
            const data = await Assignment.find({ instructorFollow: idInstructor });
            res.json(data);
        } catch (error) {
            res.status(500).json({ message: error.message });
        }
    },
    listtechnicalinstructor: async (req, res) => {
        try {
            const idInstructor = req.params.idinstructor;
            const data = await Assignment.find({ instructorTechnical: idInstructor });
            res.json(data);
        } catch (error) {
            res.status(500).json({ message: error.message });
        }
    },
    listprojectinstructor: async (req, res) => {
        try {
            const idInstructor = req.params.idinstructor;
            const data = await Assignment.find({ instructorProject: idInstructor });
            res.json(data);
        } catch (error) {
            res.status(500).json({ message: error.message });
        }
    },
    addassignment: async (req, res) => {
        const body = req.body;
        try {
            const data = new Assignment(body);
            await data.save();
            res.json({ message: "Asignación agregada" });
        } catch (error) {
            res.status(400).json({ message: error.message });
        }
    },
    updateassignmentbyid: async (req, res) => {
        const id = req.params.id;
        const body = req.body;
        try {
            const updatedAssignment = await Assignment.findByIdAndUpdate(id, body, { new: true });
            if (!updatedAssignment) return res.status(404).json({ message: "Asignación no encontrada" });
            res.json({ message: "Asignación actualizada" });
        } catch (error) {
            res.status(400).json({ message: error.message });
        }
    },
    enableassignmentbyid: async (req, res) => {
        const id = req.params.id;
        try {
            const updatedAssignment = await Assignment.findByIdAndUpdate(id, { status: 1 }, { new: true });
            if (!updatedAssignment) return res.status(404).json({ message: "Asignación no encontrada" });
            res.json({ message: "Asignación habilitada" });
        } catch (error) {
            res.status(400).json({ message: error.message });
        }
    },
    disableassignmentbyid: async (req, res) => {
        const id = req.params.id;
        try {
            const updatedAssignment = await Assignment.findByIdAndUpdate(id, { status: 0 }, { new: true });
            if (!updatedAssignment) return res.status(404).json({ message: "Asignación no encontrada" });
            res.json({ message: "Asignación deshabilitada" });
        } catch (error) {
            res.status(400).json({ message: error.message });
        }
    }
};

export { httpAssignment };
