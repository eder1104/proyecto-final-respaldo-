import axios from "axios";

// const token = 'tu-token-aqui'; // Asegúrate de obtener el token de manera segura
// const role = 'tu-rol-aqui'; // Asegúrate de obtener el rol de manera segura

const apiRepfora = axios.create({
    baseURL: 'http://89.116.49.65:4500/api/',
    headers: {
        "token": token,
        "role": role
    }
    // Puedes agregar headers u otras configuraciones aquí si es necesario
});

export default apiRepfora;