import { Router } from "express";
import { httpFollowup } from "../controllers/followup.js";
import { check } from 'express-validator';
import { validarJWT } from "./../middlewares/validarJWT.js"
// Comentar "validarJWT" para probar los endpoints sin token.

const router = Router();

router.get("/listallfollowup", [
    /* validarJWT, */
], httpFollowup.listallfollowup);

router.get("/listfollowupbyid/:id", [
    /* validarJWT, */
    check('id', 'El ID no es válido').isMongoId()
], httpFollowup.listfollowupbyid);

router.get("/listfollowupbyassignment/:idassignment", [
    /* validarJWT, */
    check('idassignment', 'El ID de la asignación no es válido').isMongoId()
], httpFollowup.listfollowupbyassignment);

router.get("/listfollowupbyinstructor/:idinstructor", [
    /* validarJWT, */
    check('idinstructor', 'El ID del instructor no es válido').isMongoId()
], httpFollowup.listfollowupbyinstructor);

router.post("/addfollowup", [
    /* validarJWT, */
    check('assignment', 'El ID de la asignación es obligatorio y debe ser válido').isMongoId(),
    check('instructor', 'El ID del instructor es obligatorio y debe ser válido').isMongoId(),
    check('number', 'El número es obligatorio y debe ser 1, 2 o 3').isIn([1, 2, 3]),
    check('status', 'El estado debe ser 1, 2, 3 o 4').optional().isIn([1, 2, 3, 4])
], httpFollowup.addfollowup);

router.put("/updatefollowupbyid/:id", [
    /* validarJWT, */
    check('id', 'El ID no es válido').isMongoId(),
    check('assignment', 'El ID de la asignación debe ser válido').optional().isMongoId(),
    check('instructor', 'El ID del instructor debe ser válido').optional().isMongoId(),
    check('number', 'El número debe ser 1, 2 o 3').optional().isIn([1, 2, 3]),
    check('status', 'El estado debe ser 1, 2, 3 o 4').optional().isIn([1, 2, 3, 4])
], httpFollowup.updatefollowupbyid);

router.put("/changefollowupstatusbyid/:id", [
    /* validarJWT, */
    check('id', 'El ID no es válido').isMongoId(),
    check('status', 'El estado es obligatorio y debe ser 1, 2, 3 o 4').isIn([1, 2, 3, 4])
], httpFollowup.changefollowupstatusbyid);

export default router;
