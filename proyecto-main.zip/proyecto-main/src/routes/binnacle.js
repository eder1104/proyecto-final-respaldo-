
import { Router } from "express";
import { httpBinnacles } from "../controllers/binnacle.js";
import { check } from 'express-validator';
import { validarJWT } from "./../middlewares/validarJWT.js"
// Comentar "validarJWT" para probar los endpoints sin token

const router = Router();

router.get("/listallbinnacles", [
    /* validarJWT, */
], httpBinnacles.listallbinnacles);

router.get("/listbinnaclesbyid/:id", [
    /* validarJWT, */
], httpBinnacles.listbinnaclesbyid);

router.get("/listbinnaclesbyassignment/:idassignment", [
    /* validarJWT, */
], httpBinnacles.listbinnaclesbyassignment);

router.get("/listbinnaclesbyinstructor/:idinstructor", [
    /* validarJWT, */
], httpBinnacles.listbinnaclesbyinstructor);

router.post("/addbinnacles", [
    /* validarJWT, */
    check("ficha", "La ficha es obligatoria").not().isEmpty(),
    check("assignment", "la asignacion es obligatoria").not().isEmpty(),
    check("instructor", "indique el instructor").not().isEmpty(),
    check("number", "el numero es obligatorio").not().isEmpty(),
    check("users", "el usuario es obligatorio").not().isEmpty(),
], httpBinnacles.addbinnacles);

router.put("/updatebinnaclebyid/:id", [
    /* validarJWT, */
], httpBinnacles.updatebinnaclesbyid);

router.put("/checktecnicalhours", [
    /* validarJWT, */
    check("id", "El id es obligatorio").not().isEmpty(),
    check("hours", "Las horas son obligatorias").not().isEmpty(),
], httpBinnacles.checktecnicalhours);

router.put("/checkprojecthours", [
    /* validarJWT, */
    check("id", "El id es obligatorio").not().isEmpty(),
    check("hours", "Las horas son obligatorias").not().isEmpty(),
], httpBinnacles.checkprojecthours);

router.put("/updatestatus/:id/:status", [
    /* validarJWT, */
    check("status", "El estado es obligatorio").not().isEmpty(),
    check("id", "El id es obligatorio").not().isEmpty(),
], httpBinnacles.updatestatus);

export default router;
