import { Router } from "express";
import { httpAssignment } from "../controllers/assignment.js";
import { check } from 'express-validator';
import { validarJWT } from "./../middlewares/validarJWT.js";
import validarCampos from '../middlewares/validarCampos.js';

const router = Router();

router.get("/listallassignment", [
    /* validarJWT, */
], httpAssignment.listallassignment);

router.get("/listassignmentbyid/:id", [
    /* validarJWT, */
    check('id', 'El ID no es válido').isMongoId(),
    validarCampos
], httpAssignment.listassignmentbyid);

router.get("/listassignmentbyregister/:idregister", [
    /* validarJWT, */
    check('idregister', 'El ID de la ficha no es válido').isMongoId(),
    validarCampos
], httpAssignment.listassignmentbyregister);

router.get("/listassignmentbyfollowupinstructor/:idinstructor", [
    /* validarJWT, */
    check('idinstructor', 'El ID del instructor no es válido').isMongoId(),
    validarCampos
], httpAssignment.listfollowupinstructor);

router.get("/listassignmentbytechnicalinstructor/:idinstructor", [
    /* validarJWT, */
    check('idinstructor', 'El ID del instructor no es válido').isMongoId(),
    validarCampos
], httpAssignment.listtechnicalinstructor);

router.get("/listassignmentbyprojectinstructor/:idinstructor", [
    /* validarJWT, */
    check('idinstructor', 'El ID del instructor no es válido').isMongoId(),
    validarCampos
], httpAssignment.listprojectinstructor);

router.post("/addassignment", [
    /* validarJWT, */
    check("register", "El ID de la ficha es obligatorio y debe ser válido").not().isEmpty().isMongoId(),
    check("instructorFollow", "El ID del instructor de seguimiento es obligatorio y debe ser válido").not().isEmpty().isMongoId(),
    check("instructorTechnical", "El ID del instructor técnico es obligatorio y debe ser válido").not().isEmpty().isMongoId(),
    check("instructorProject", "El ID del instructor de proyectos es obligatorio y debe ser válido").not().isEmpty().isMongoId(),
    validarCampos
], httpAssignment.addassignment);

router.put("/updateassignmentbyid/:id", [
    /* validarJWT, */
    check('id', 'El ID no es válido').isMongoId(),
    check("register", "El ID de la ficha debe ser válido").optional().isMongoId(),
    check("instructorFollow", "El ID del instructor de seguimiento debe ser válido").optional().isMongoId(),
    check("instructorTechnical", "El ID del instructor técnico debe ser válido").optional().isMongoId(),
    check("instructorProject", "El ID del instructor de proyectos debe ser válido").optional().isMongoId(),
    validarCampos
], httpAssignment.updateassignmentbyid);

router.put("/enableassignmentbyid/:id", [
    /* validarJWT, */
    check('id', 'El ID no es válido').isMongoId(),
    validarCampos
], httpAssignment.enableassignmentbyid);

router.put("/disableassignmentbyid/:id", [
    /* validarJWT, */
    check('id', 'El ID no es válido').isMongoId(),
    validarCampos
], httpAssignment.disableassignmentbyid);

export default router;
