import { Router } from "express";
import { httpRegister } from "../controllers/register.js";
import { check } from 'express-validator';
import { validarJWT } from "./../middlewares/validarJWT.js";
import validarCampos  from '../middlewares/validarCampos.js';  // Middleware para manejar errores de validación
// comenté el validarJWT para probar los endpoints sin token


const router = Router();

router.get("/listallregister", [
  /* validarJWT, */
], httpRegister.listallregister);

router.get("/listallregisterwithassignment", [
  /* validarJWT, */
], httpRegister.listallregisterwithassignment);

router.get("/listregisterbyid/:id", [
  /* validarJWT, */
  check('id', 'El ID no es válido').isMongoId(),
  validarCampos
], httpRegister.listregisterbyid);

router.get("/listregisterbyapprentice/:idapprentice", [
  /* validarJWT, */
  check('idapprentice', 'El ID del aprendiz no es válido').isMongoId(),
  validarCampos
], httpRegister.listregisterbyapprentice);

router.get("/listregistersbyfiche/:idfiche", [
  /* validarJWT, */
  check('idfiche', 'El ID de la ficha no es válido').isMongoId(),
  validarCampos
], httpRegister.listregistersbyfiche);

router.get("/listregisterbymodality/:idmodality", [
  /* validarJWT, */
  check('idmodality', 'El ID de la modalidad no es válido').isMongoId(),
  validarCampos
], httpRegister.listregisterbymodality);

router.get("/listregisterbystartdate/:startdate", [
  /* validarJWT, */
  check('startdate', 'La fecha de inicio no es válida').isISO8601(),
  validarCampos
], httpRegister.listregisterbystartdate);

router.get("/listregisterbyenddate/:enddate", [
  /* validarJWT, */
  check('enddate', 'La fecha de fin no es válida').isISO8601(),
  validarCampos
], httpRegister.listregisterbyenddate);



// -----------------------------------------------------------------------------------------------------------------------
// Ruta para listar registros por ID del instructor de seguimiento
router.get("/listregisterepbyfollowupinstructor/:idinstructor", [
  /* validarJWT, */
  check('idinstructor', 'El ID del instructor no es válido').isMongoId(),
  validarCampos
], httpRegister.listregisterepbyfollowupinstructor);

// Ruta para listar registros por ID del instructor técnico
router.get("/listregisterepbytechnicalinstructor/:idinstructor", [
  /* validarJWT, */
  check('idinstructor', 'El ID del instructor no es válido').isMongoId(),
  validarCampos
], httpRegister.listregisterepbytechnicalinstructor);

// Ruta para listar registros por ID del instructor de proyecto
router.get("/listregisterepbyprojectinstructor/:idinstructor", [
  /* validarJWT, */
  check('idinstructor', 'El ID del instructor no es válido').isMongoId(),
  validarCampos
], httpRegister.listregisterepbyprojectinstructor);
// ----------------------------------------------------------------------------------------------------------------------



router.post("/addregister", [
  /* validarJWT, */
  check("apprentice", "El aprendiz es obligatorio").not().isEmpty().isMongoId(),
  check("modality", "La modalidad es obligatoria").not().isEmpty().isMongoId(),
  check("startDate", "La fecha de inicio es obligatoria y debe ser válida").not().isEmpty().isISO8601(),
  check("endDate", "La fecha de fin es obligatoria y debe ser válida").not().isEmpty().isISO8601(),
  check("company", "El nombre de la empresa es obligatorio").not().isEmpty(),
  check("phoneCompany", "El teléfono de la empresa es obligatorio").not().isEmpty().isMobilePhone(),
  check("addressCompany", "La dirección de la empresa es obligatoria").not().isEmpty(),
  check("emailCompany", "El correo de la empresa debe ser válido").not().isEmpty().isEmail(),
  check("owner", "El propietario es obligatorio").not().isEmpty(),
  // check("docAlternative", "El documento alternativo es obligatorio").not().isEmpty(),
  // check("hour", "El número de horas es obligatorio y debe ser un número").not().isEmpty().isNumeric(),
  validarCampos
], httpRegister.addregister);

router.put("/updateregisterbyid/:id", [
  /* validarJWT, */
  check('id', 'El ID no es válido').isMongoId(),
  check("startDate", "La fecha de inicio debe ser válida").optional().isISO8601(),
  check("endDate", "La fecha de fin debe ser válida").optional().isISO8601(),
  check("emailCompany", "El correo de la empresa debe ser válido").optional().isEmail(),
  check("phoneCompany", "El teléfono de la empresa debe ser válido").optional().isMobilePhone(),
  check("hour", "El número de horas debe ser un número").optional().isNumeric(),
  validarCampos
], httpRegister.updateregisterbyid);

router.put("/updateassignmentregister/:id", [
  /* validarJWT, */
  check('id', 'El ID no es válido').isMongoId(),
  check("instructorFollow", "El instructor de seguimiento es obligatorio").not().isEmpty().isMongoId(),
  check("instructorProject", "El instructor de proyecto es obligatorio").not().isEmpty().isMongoId(),
  check("instructorTechnical", "El instructor técnico es obligatorio").not().isEmpty().isMongoId(),
  validarCampos
], httpRegister.updateassignmentregister);

router.put("/updatemodalityregister/:id", [
  /* validarJWT, */
  check('id', 'El ID no es válido').isMongoId(),
  check("modality", "La modalidad es obligatoria").not().isEmpty().isMongoId(),
  validarCampos
], httpRegister.updatemodalityregister);

router.put("/enableregister/:id", [
  /* validarJWT, */
  check('id', 'El ID no es válido').isMongoId(),
  validarCampos
], httpRegister.enableregister);

router.put("/disableregister/:id", [
  /* validarJWT, */
  check('id', 'El ID no es válido').isMongoId(),
  validarCampos
], httpRegister.disableregister);

export default router;
