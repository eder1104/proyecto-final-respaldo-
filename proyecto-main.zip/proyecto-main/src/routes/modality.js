
import { Router } from "express";
import { httpModality } from "../controllers/modality.js";
import { check } from 'express-validator';
import { validarJWT } from "./../middlewares/validarJWT.js"
// Comentar "validarJWT" para probar los endpoints sin token

const router = Router();

router.get("/listallmodality", [
    /* validarJWT, */
], httpModality.listallmodality);

router.get("/listmodalitybyid/:id", [
    /* validarJWT, */
], httpModality.listmodalitybyid);

router.post("/addmodality", [
    /* validarJWT, */
    check("name", "el nombre es obligatorio").not().isEmpty(),
    check("hourInstructorFollow"),
    check("hourInstructorTechnical"),
    check("hourInstructorProject"),
    check("createdAt"),
    check("updatedAt"),
], httpModality.addmodality);

router.put("/updatemodalitybyid/:id", [
    /* validarJWT, */
], httpModality.updatemodalitybyid);

router.put("/enablemodalitybyid/:id", [
    /* validarJWT, */
], httpModality.enablemodality);

router.put("/disablemodalitybyid/:id", [
    /* validarJWT, */
], httpModality.disablemodality);


export default router;
