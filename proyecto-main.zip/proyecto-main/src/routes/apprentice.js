import { Router } from "express";
import { httpApprentice } from "../controllers/apprentice.js";
import { check } from 'express-validator';
// import { ValidarAdministradorJWT, ValidarJWTAprendiz } from "./../middlewares/validarJWT.js";
import validarCampos from '../middlewares/validarCampos.js';
// Comentar "validarJWT" para probar los endpoints sin token

const router = Router();


router.get("/listallapprentice", [
    // ValidarJWTAprendiz,
    // ValidarAdministradorJWT
], httpApprentice.listallapprentice);

router.get("/listapprenticebyid/:id", [
    // ValidarJWTAprendiz,
    // ValidarAdministradorJWT,
    check('id', 'El ID no es válido').isMongoId(),
    validarCampos
], httpApprentice.listapprenticebyid);

router.get("/listapprenticebyfiche/:id", [
    // ValidarJWTAprendiz,
    check('id', 'El ID de la ficha no es válido').isMongoId(),
    validarCampos
], httpApprentice.listapprenticebyfiche);

router.get("/listapprenticebystatus/:status", [
    // ValidarJWTAprendiz,
    check('status', 'El estado debe ser un número válido').isInt({ min: 1, max: 5 }),
    validarCampos
], httpApprentice.listapprenticebystatus);

router.post("/addapprentice", [
    // ValidarJWTAprendiz,
    check('tpDocument', 'El tipo de documento es obligatorio').not().isEmpty(),
    check('numDocument', 'El número de documento es obligatorio y debe ser único').not().isEmpty(),
    check('firstName', 'El nombre es obligatorio').not().isEmpty(),
    check('lastName', 'El apellido es obligatorio').not().isEmpty(),
    check('email', 'El correo electrónico no es válido').isEmail(),
    validarCampos
], httpApprentice.addapprentice);

router.post("/loginapprentice", [
    check('email', 'El correo electrónico es obligatorio').not().isEmpty(),
    check('numDocument', 'El número de documento es obligatorio').not().isEmpty(),
    validarCampos
], httpApprentice.loginapprentice);

router.put("/updateapprenticebyid/:id", [
    // ValidarJWTAprendiz,
    check('id', 'El ID no es válido').isMongoId(),
    check('email', 'El correo electrónico no es válido').optional().isEmail(),
    validarCampos
], httpApprentice.updateapprenticebyid);

router.put("/enableapprentice/:id", [
    // ValidarJWTAprendiz,
    check('id', 'El ID no es válido').isMongoId(),
    validarCampos
], httpApprentice.enableapprentice);

router.put("/disableapprentice/:id", [
    // ValidarJWTAprendiz,
    check('id', 'El ID no es válido').isMongoId(),
    validarCampos
], httpApprentice.disableapprentice);

export default router;