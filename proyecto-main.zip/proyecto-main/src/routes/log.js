import { Router } from "express";
import { httpLog } from "../controllers/log.js";
import { check } from 'express-validator';
import { validarJWT } from "./../middlewares/validarJWT.js";
import validarCampos from '../middlewares/validarCampos.js';  // Middleware para manejar errores de validación
// Comentar "validarJWT" para probar los endpoints sin token

const router = Router();

router.get("/listlogs", [
    /* validarJWT, */
], httpLog.listlogs);

router.get("/listlogsbyid/:id", [
    /* validarJWT, */
    check('id', 'El ID no es válido').isMongoId(),
    validarCampos
], httpLog.listlogsbyid);

router.post("/addlog", [
    /* validarJWT, */
    check('name', 'El nombre es obligatorio').not().isEmpty(),
    check('action', 'La acción es obligatoria').not().isEmpty(),
    check('information.message', 'El mensaje es obligatorio').not().isEmpty(),
    validarCampos
], httpLog.addlog);

router.put("/enablelogsbyid/:id", [
    /* validarJWT, */
    check('id', 'El ID no es válido').isMongoId(),
    validarCampos
], httpLog.enablelogsbyid);

router.put("/disablelogsbyid/:id", [
    /* validarJWT, */
    check('id', 'El ID no es válido').isMongoId(),
    validarCampos
], httpLog.disablelogsbyid);

export default router;
