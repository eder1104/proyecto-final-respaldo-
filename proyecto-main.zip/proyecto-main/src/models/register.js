import { Schema, model } from 'mongoose';

const registerSchema = new Schema({
  apprentice: { type: Schema.Types.ObjectId, ref: 'Apprentice', required: true },
  modality: { type: Schema.Types.ObjectId, ref: 'Modality', required: true },
  assignment: {
    instructorFollow: {
      id: { type: Schema.Types.ObjectId },
      name: { type: String },
      status: { type: Number, default: 1 },
      the: {
        hours: { type: Number, default: 0 }
      },
      thp: {
        hours: { type: Number, default: 0 }
      }
    },
    instructorProject: {
      id: { type: Schema.Types.ObjectId },
      name: { type: String },
      status: { type: Number, default: 1 },
      the: {
        hours: { type: Number, default: 0 }
      },
      thp: {
        hours: { type: Number, default: 0 }
      }
    },
    instructorTechnical: {
      id: { type: Schema.Types.ObjectId },
      name: { type: String },
      status: { type: Number, default: 1 },
      the: {
        hours: { type: Number, default: 0 }
      },
      thp: {
        hours: { type: Number, default: 0 }
      }
    },
    status: { type: Number, default: 1 },
  },
  the: {
    hours: { type: Number, default: 0 }
  },
  thp: {
    hours: { type: Number, default: 0 }
  },
  th: {
    hours: { type: Number, default: 864 }
  },
  startDate: { type: Date, required: true },
  endDate: { type: Date, required: true },
  company: { type: String, required: true },
  phoneCompany: { type: String, required: true },
  addressCompany: { type: String, required: true },
  emailCompany: { type: String, required: true },
  owner: { type: String, required: true },
  docAlternative: {
    docs: { type: String }
  },
  businessProyectHour: { type: Number },
  productiveProjectHour: { type: Number }
}, { timestamps: true });

export default model('Register', registerSchema);