import { Schema, model } from 'mongoose';

const logSchema = new Schema({
    name: { type: String, required: true },
    action: { type: String, required: true },
    information: {
        message: { type: String, required: true }
    },
    data: {
        
    }

}, { timestamps: true });

export default model('Log', logSchema);