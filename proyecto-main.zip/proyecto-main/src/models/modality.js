
import { Schema, model } from 'mongoose';

const modalitySchema = new Schema({
    name: { type: String, required: true, unique: true },
      hourInstructorFollow: { 
        idInstructor: { type: Schema.Types.ObjectId }, 
        name: { type: String }
      },
      hourInstructorTechnical: { 
        idInstructor: { type: Schema.Types.ObjectId }, 
        name: { type: String }
      },
      hourInstructorProject: { 
        idInstructor: { type: Schema.Types.ObjectId }, 
        name: { type: String }
      }
}, { timestamps: true });

export default model('Modality', modalitySchema);