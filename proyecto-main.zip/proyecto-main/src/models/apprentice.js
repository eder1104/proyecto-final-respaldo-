import { Schema, SchemaType, model } from 'mongoose';

const apprenticeSchema = new Schema({
    tpDocument: { type: String, required: true },
    numDocument: { type: String, required: true, unique: true },
    firstName: { type: String, required: true },
    lastName: { type: String, required: true },
    phone: { type: String },
    email: { type: String, required: true, unique: true },
    modality: { type: Schema.Types.ObjectId, ref: 'Modality', required: true },
    fiche: {
        id: { type: Schema.Types.ObjectId },
        name: { type: String },
        number: { type: String }
    },
    the: {
        hours: { type: Number, default: 0 }
    },
    thp: {
        hours: { type: Number, default: 0 }
    },
    th: {
        hours: { type: Number, default: 864 }
    },
    status: { type: String, enum: [1, 2, 3, 4, 5], default: 1 },
    // status: { type: String, enum: [
    //     "ACTIVO", 
    //     "INACTIVO", 
    //     "EN ETAPA PRODUCTIVA", 
    //     "POR CERTIFICAR", 
    //     "CERTIFICADO"
    // ], default: "ACTIVO"},
    createdAt: { type: Date, default: Date.now },
    updatedAt: { type: Date, default: Date.now }
}, { timestamps: true });

export default model('Apprentice', apprenticeSchema);