import { Schema, model } from 'mongoose';

const followupSchema = new Schema({
    // assignment: { type: Schema.Types.ObjectId, ref: 'Assignment', required: true },
    assignment: { type: Schema.Types.ObjectId, ref: 'Register', required: true },
    instructor: { type: Schema.Types.ObjectId, ref: 'Instructor', required: true },
    number: { type: Number, required: true, enum: [1, 2, 3] },
    month: { type: Date },
    document: { type: String },
    status: { type: Number, enum: [1, 2, 3, 4], default: 1 },
    observations: [{
        observation: String,
        user: { type: Schema.Types.ObjectId },
        observationDate: Date,
    }]
}, { timestamps: true });

export default model('Followup', followupSchema);
