import express, { json } from "express";
import cors from "cors";
import http from "http";
import { connect } from 'mongoose';

import apprenticeRoutes from "../routes/apprentice.js";
import assignmentRoutes from "../routes/assignment.js";
import binnaclesRoutes from "../routes/binnacle.js";
import folloupRoutes from "../routes/followup.js";
import logsRoutes from "../routes/log.js";
import modalityRoutes from "../routes/modality.js";
import registerRoutes from "../routes/register.js";

class Server {
    constructor() {
        this.app = express();
        this.port = process.env.PORT;
        this.server = http.createServer(this.app);

        // Middlewares
        this.middlewares();

        // Rutas de mi aplicación
        this.routes();
    }

    middlewares() {
        // CORS
        this.app.use(cors());

        // Directorio Público
        this.app.use(express.static("public"));

        this.app.use(json());
    }

    routes() {
        this.app.use("/api/apprentice", apprenticeRoutes);
        this.app.use("/api/assignment", assignmentRoutes);
        this.app.use("/api/binnacles", binnaclesRoutes);
        this.app.use("/api/followup", folloupRoutes);
        this.app.use("/api/logs", logsRoutes);
        this.app.use("/api/modality", modalityRoutes);
        this.app.use("/api/register", registerRoutes);
    }

    listen() {
        this.server.listen(this.port, () => {
            console.log("Servidor corriendo en puerto", this.port);
            connect("mongodb+srv://admin:admin@repforaproyecto.zvvh8.mongodb.net/?retryWrites=true&w=majority&appName=repforaProyecto").then(() => console.log('Connected!'));
        });
    }
}

export { Server };
