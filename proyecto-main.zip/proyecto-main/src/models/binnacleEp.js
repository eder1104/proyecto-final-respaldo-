import { Schema, SchemaType, model } from 'mongoose';

const binnacleSchema = new Schema({
    // assignment: { type: Schema.Types.ObjectId, ref: 'Assignment', required: true },
    assignment:{ type: Schema.Types.ObjectId, ref: 'Register', required: true},
    instructor: { type: Schema.Types.ObjectId, required: true },
    number: { type: Number, required: true, enum: [1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12] },
    document: String,
    status: { type: Number, enum: [1, 2, 3, 4, 5], default: 1 },
    // status: { type: String, enum: [
    //     "PENDIENTE",
    //     "EJECUTADA",
    //     "VERIFICADOS TODOS",
    //     "VERIFICADO INS. PROYECTO",
    //     "VERIFICADO INS. SEGUIMIENTO"
    // ], default: "ACTIVO" },
    observations: [{
        observation: String,
        // user: { type: Schema.Types.ObjectId, ref: 'UserEp' },
        observationDate: Date,
    }],
}, { timestamps: true });

export default model('Binnacle', binnacleSchema);