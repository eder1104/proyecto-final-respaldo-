function processRole(role) {
    if (!role) {
      throw new Error("No se ha proporcionado ningún rol");
    }
    switch (role) {
      case 'ETAPA PRODUCTIVA':
        return 'Administrador';
      case 'instructor':
        return 'Instructor';
      case 'consultor':
        return 'Aprendiz';
      default:
        throw new Error("Rol no válido");
    }
  }
  
  export { processRole };