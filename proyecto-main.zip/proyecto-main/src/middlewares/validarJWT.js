import axios from 'axios';
import { processRole } from '../middlewares/validateRole.js';
import jwt from 'jsonwebtoken';
import Apprentice from '../models/apprentice.js';

const repfora = process.env.urlRepfora;
const rol = processRole;

// ValidarAdministradorJWT
// ValidarInstructorJWT
// ValidarAprendizJWT

const ValidarAdministradorJWT = async (req, res, next) => {
    const { token } = req.headers;

    if (!token) {
        return res.status(401).json({
            msg: 'Token no proveído'
        });
    }

    try {
        const validate = await axios.post(`${repfora}/api/users/token/productive/stages`, null, {
            headers: { token: token }
        });
        if (validate.data.token === true) {

            req.userData = validate.data;

            return next();
        } else {
            return res.status(400).json({
                msg: 'Token inválido',
                data: validate.data
            });
        }
    } catch (error) {
        return res.status(error.response?.status || 500).json({
            message: error.response?.data?.message || error.message,
            status: error.response?.status,
            data: error.response?.data
        });
    }
};
const ValidarInstructorJWT = async (req, res, next) => {
    const { token } = req.headers;

    if (!token) {
        return res.status(401).json({
            msg: 'Token no proveído'
        });
    }

    try {
        const validate = await axios.post(`${repfora}/api/users/token/productive/stages`, null, {
            headers: { token: token }
        });
        if (validate.data.token === true) {

            req.userData = validate.data;

            return next();
        } else {
            return res.status(400).json({
                msg: 'Token inválido',
                data: validate.data
            });
        }
    } catch (error) {
        return res.status(error.response?.status || 500).json({
            message: error.response?.data?.message || error.message,
            status: error.response?.status,
            data: error.response?.data
        });
    }
};
const ValidarJWTAprendiz = async (req, res, next) => {
    const { token } = req.headers;

    if (!token) {
        return res.status(401).json({
            msg: "Error: No hay token en la petición"
        })
    }

    try {
        let usuario;

        const { uid } = jwt.verify(token, process.env.SECRETORPRIVATEKEY)
        if (!uid) {
            return res.status(401).json({
                msg: "Error en la petición2"
            })
        }

        usuario = await Apprentice.findById(uid);


        if (!usuario) {
            return res.status(401).json({
                msg: "Error en la petición! ."//- usuario no existe DB
            })
        }

        if (usuario.estado == 0) {
            return res.status(401).json({
                msg: "Token no válido!!  " //- usuario con estado: false
            })
        }

        next();

    } catch (error) {


        res.status(401).json({
            msg: "Token no valido"
        })
    }
}

const validarJWT = (req, res, next) =>{
    if (rol === 'Administrador') {
        return ValidarAdministradorJWT;
    } else if (rol === 'Instructor') {
        return ValidarInstructorJWT;
    } else if (rol === 'Aprendiz') {
        return ValidarJWTAprendiz
    }
};

const generarJWTaprendiz = (uid) => {
    return new Promise((resolve, reject) => {
        const payload = { uid };
        jwt.sign(payload, process.env.SECRETORPRIVATEKEY, {
            //100 years
            expiresIn: "100y"

        }, (err, token) => {
            if (err) {

                reject("No se pudo generar el token")
            } else {
                resolve(token)
            }
        })
        
    })
}



// export { validarJWT, generarJWTaprendiz };
export { generarJWTaprendiz, ValidarAdministradorJWT, ValidarInstructorJWT, ValidarJWTAprendiz, validarJWT};